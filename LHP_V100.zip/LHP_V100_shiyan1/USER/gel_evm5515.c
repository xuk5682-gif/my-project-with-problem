/********************************************************************/
/* evm5515.gel                                                    */
/* Version 0.02                                                     */
/*                                                                  */
/* This GEL file is to be used with the 5515 EVM.                 */
/* Changes may be required to support specific hardware designs.    */
/*                                                                  */
/* Code Composer Studio supports six reserved GEL functions that    */
/* automatically get executed if they are defined. They are:        */
/*                                                                  */
/* StartUp()              - Executed whenever CCS is invoked        */
/* OnReset()              - Executed after Debug->Reset CPU         */
/* OnRestart()            - Executed after Debug->Restart           */
/* OnPreFileLoaded()      - Executed before File->Load Program      */
/* OnFileLoaded()         - Executed after File->Load Program       */
/* OnTargetConnect()      - Executed after Debug->Connect           */
/*                                                                  */
/*   Version History                                                */
/*     v0.01        Initial Release                                 */
/*     v0.02        Corrected PLL settings                          */
/********************************************************************/
#include"gel_evm5515.h"
#include <tistdtypes.h>
//StartUp()
//{
//    c5515_MapInit();
//}

/*--------------------------------------------------------------*/
/* OnTargetConnect() -- this function is called after a target  */
/* connect.                                                     */
/*--------------------------------------------------------------*/
void OnTargetConnect()
{
//    GEL_Reset();
    Peripheral_Reset();
   // ProgramPLL_100MHz();
    //SDRAM_INIT();
//    GEL_TextOut("Target Connection Complete.\n");
}

/*--------------------------------------------------------------*/
/* OnPreFileLoaded()                                            */
/* This function is called automatically when the 'Load Program'*/
/* Menu item is selected.                                       */
/*--------------------------------------------------------------*/
//OnPreFileLoaded()
//{
//    /* Reset the CPU to clean up state */
//    //GEL_Reset();
//}

/*--------------------------------------------------------------*/
/* OnRestart()                                                  */
/* This function is executed before a file is restarted. Disable*/
/* interrupts and DMA from the current program so pending       */
/* events and transfers don't interfere with the new program.   */
/*--------------------------------------------------------------*/
void OnRestart()
{
    /* Disable interrupts */
    *(volatile ioport Uint16 *)0x0003 = *(volatile ioport Uint16 *)0x0003 | 0x0800; //*(int*)0x0003 = *(int*)0x0003 | 0x0800; // Set INTM
    *(volatile ioport Uint16 *)0x0000 = 0;      //*(int*)0x0000 = 0;      // Clear IER0
    *(volatile ioport Uint16 *)0x0045 = 0;      //*(int*)0x0000 = 0;      // Clear IER1
}
/*--------------------------------------------------------------*/
/* OnReset()                                                    */
/* This function is called by CCS when you do Debug->Resest.    */
/* The goal is to put the C55xx into a known good state with    */
/* respect to cache, dma and interrupts.                        */
/*--------------------------------------------------------------*/
//OnReset( int nErrorCode )
//{
//}

/*--------------------------------------------------------------*/
/* OnFileLoaded()                                               */
/* This function is called by CCS when you do File->Load Program*/
/* The goal is to do in post file loaded configuration that may */
/* be needed.                                                   */
/*--------------------------------------------------------------*/
//OnFileLoaded()
//{
//}



// ***************************************************************************

///* Memory map based on MP/MC value (assume MP/MC = 0).    */
//c5515_MapInit() {
//    GEL_MapOn();
//    GEL_MapReset();
//
//    /*Program Space*/
//
//    /* DARAM */
//    GEL_MapAdd(0x0000C0,0,0x001F40,1,1);    /* DARAM0 */
//    GEL_MapAdd(0x002000,0,0x002000,1,1);    /* DARAM1 */
//    GEL_MapAdd(0x004000,0,0x002000,1,1);    /* DARAM2 */
//    GEL_MapAdd(0x006000,0,0x002000,1,1);    /* DARAM3 */
//    GEL_MapAdd(0x008000,0,0x002000,1,1);    /* DARAM4 */
//    GEL_MapAdd(0x00A000,0,0x002000,1,1);    /* DARAM5 */
//    GEL_MapAdd(0x00C000,0,0x002000,1,1);    /* DARAM6 */
//    GEL_MapAdd(0x00E000,0,0x002000,1,1);    /* DARAM7 */
//
//    /* SARAM */
//    GEL_MapAdd(0x010000,0,0x002000,1,1);    /* SARAM0 */
//    GEL_MapAdd(0x012000,0,0x002000,1,1);    /* SARAM1 */
//    GEL_MapAdd(0x014000,0,0x002000,1,1);    /* SARAM2 */
//    GEL_MapAdd(0x016000,0,0x002000,1,1);    /* SARAM3 */
//    GEL_MapAdd(0x018000,0,0x002000,1,1);    /* SARAM4 */
//    GEL_MapAdd(0x01A000,0,0x002000,1,1);    /* SARAM5 */
//    GEL_MapAdd(0x01C000,0,0x002000,1,1);    /* SARAM6 */
//    GEL_MapAdd(0x01E000,0,0x002000,1,1);    /* SARAM7 */
//    GEL_MapAdd(0x020000,0,0x002000,1,1);    /* SARAM8 */
//    GEL_MapAdd(0x022000,0,0x002000,1,1);    /* SARAM9 */
//    GEL_MapAdd(0x024000,0,0x002000,1,1);    /* SARAM10 */
//    GEL_MapAdd(0x026000,0,0x002000,1,1);    /* SARAM11 */
//    GEL_MapAdd(0x028000,0,0x002000,1,1);    /* SARAM12 */
//    GEL_MapAdd(0x02A000,0,0x002000,1,1);    /* SARAM13 */
//    GEL_MapAdd(0x02C000,0,0x002000,1,1);    /* SARAM14 */
//    GEL_MapAdd(0x02E000,0,0x002000,1,1);    /* SARAM15 */
//    GEL_MapAdd(0x030000,0,0x002000,1,1);    /* SARAM16 */
//    GEL_MapAdd(0x032000,0,0x002000,1,1);    /* SARAM17 */
//    GEL_MapAdd(0x034000,0,0x002000,1,1);    /* SARAM18 */
//    GEL_MapAdd(0x036000,0,0x002000,1,1);    /* SARAM19 */
//    GEL_MapAdd(0x038000,0,0x002000,1,1);    /* SARAM20 */
//    GEL_MapAdd(0x03A000,0,0x002000,1,1);    /* SARAM21 */
//    GEL_MapAdd(0x03C000,0,0x002000,1,1);    /* SARAM22 */
//    GEL_MapAdd(0x03E000,0,0x002000,1,1);    /* SARAM23 */
//    GEL_MapAdd(0x040000,0,0x002000,1,1);    /* SARAM24 */
//    GEL_MapAdd(0x042000,0,0x002000,1,1);    /* SARAM25 */
//    GEL_MapAdd(0x044000,0,0x002000,1,1);    /* SARAM26 */
//    GEL_MapAdd(0x046000,0,0x002000,1,1);    /* SARAM27 */
//    GEL_MapAdd(0x048000,0,0x002000,1,1);    /* SARAM28 */
//    GEL_MapAdd(0x04A000,0,0x002000,1,1);    /* SARAM29 */
//    GEL_MapAdd(0x04C000,0,0x002000,1,1);    /* SARAM30 */
//    GEL_MapAdd(0x04E000,0,0x002000,1,1);    /* SARAM31 */
//
//    /* External-Memory */
//    GEL_MapAdd(0x050000,0,0x7B0000,1,1);    /* External-SDRAM */
//    GEL_MapAdd(0x800000,0,0x400000,1,1);    /* External-Async */
//    GEL_MapAdd(0xC00000,0,0x200000,1,1);    /* External-Async */
//    GEL_MapAdd(0xE00000,0,0x100000,1,1);    /* External-Async */
//    GEL_MapAdd(0xF00000,0,0x0E0000,1,1);    /* External-Async */
//
//    /* ROM */
//    GEL_MapAdd(0xFE0000,0,0x008000,1,0);    /* SAROM0 */
//    GEL_MapAdd(0xFE8000,0,0x008000,1,0);    /* SAROM1 */
//    GEL_MapAdd(0xFF0000,0,0x008000,1,0);    /* SAROM2 */
//    GEL_MapAdd(0xFF8000,0,0x008000,1,0);    /* SAROM3 */
//
//    /* Data Space */
//
//    /* DARAM */
//    GEL_MapAdd(0x000000,1,0x000060,1,1);    /* MMRs */
//    GEL_MapAdd(0x000060,1,0x000FA0,1,1);    /* DARAM0 */
//    GEL_MapAdd(0x001000,1,0x001000,1,1);    /* DARAM1 */
//    GEL_MapAdd(0x002000,1,0x001000,1,1);    /* DARAM2 */
//    GEL_MapAdd(0x003000,1,0x001000,1,1);    /* DARAM3 */
//    GEL_MapAdd(0x004000,1,0x001000,1,1);    /* DARAM4 */
//    GEL_MapAdd(0x005000,1,0x001000,1,1);    /* DARAM5 */
//    GEL_MapAdd(0x006000,1,0x001000,1,1);    /* DARAM6 */
//    GEL_MapAdd(0x007000,1,0x001000,1,1);    /* DARAM7 */
//
//    /* SARAM */
//    GEL_MapAdd(0x008000,1,0x001000,1,1);    /* SARAM0 */
//    GEL_MapAdd(0x009000,1,0x001000,1,1);    /* SARAM1 */
//    GEL_MapAdd(0x00A000,1,0x001000,1,1);    /* SARAM2 */
//    GEL_MapAdd(0x00B000,1,0x001000,1,1);    /* SARAM3 */
//    GEL_MapAdd(0x00C000,1,0x001000,1,1);    /* SARAM4 */
//    GEL_MapAdd(0x00D000,1,0x001000,1,1);    /* SARAM5 */
//    GEL_MapAdd(0x00E000,1,0x001000,1,1);    /* SARAM6 */
//    GEL_MapAdd(0x00F000,1,0x001000,1,1);    /* SARAM7 */
//    GEL_MapAdd(0x010000,1,0x001000,1,1);    /* SARAM8 */
//    GEL_MapAdd(0x011000,1,0x001000,1,1);    /* SARAM9 */
//    GEL_MapAdd(0x012000,1,0x001000,1,1);    /* SARAM10 */
//    GEL_MapAdd(0x013000,1,0x001000,1,1);    /* SARAM11 */
//    GEL_MapAdd(0x014000,1,0x001000,1,1);    /* SARAM12 */
//    GEL_MapAdd(0x015000,1,0x001000,1,1);    /* SARAM13 */
//    GEL_MapAdd(0x016000,1,0x001000,1,1);    /* SARAM14 */
//    GEL_MapAdd(0x017000,1,0x001000,1,1);    /* SARAM15 */
//    GEL_MapAdd(0x018000,1,0x001000,1,1);    /* SARAM16 */
//    GEL_MapAdd(0x019000,1,0x001000,1,1);    /* SARAM17 */
//    GEL_MapAdd(0x01A000,1,0x001000,1,1);    /* SARAM18 */
//    GEL_MapAdd(0x01B000,1,0x001000,1,1);    /* SARAM19 */
//    GEL_MapAdd(0x01C000,1,0x001000,1,1);    /* SARAM20 */
//    GEL_MapAdd(0x01D000,1,0x001000,1,1);    /* SARAM21 */
//    GEL_MapAdd(0x01E000,1,0x001000,1,1);    /* SARAM22 */
//    GEL_MapAdd(0x01F000,1,0x001000,1,1);    /* SARAM23 */
//    GEL_MapAdd(0x020000,1,0x001000,1,1);    /* SARAM24 */
//    GEL_MapAdd(0x021000,1,0x001000,1,1);    /* SARAM25 */
//    GEL_MapAdd(0x022000,1,0x001000,1,1);    /* SARAM26 */
//    GEL_MapAdd(0x023000,1,0x001000,1,1);    /* SARAM27 */
//    GEL_MapAdd(0x024000,1,0x001000,1,1);    /* SARAM28 */
//    GEL_MapAdd(0x025000,1,0x001000,1,1);    /* SARAM29 */
//    GEL_MapAdd(0x026000,1,0x001000,1,1);    /* SARAM30 */
//    GEL_MapAdd(0x027000,1,0x001000,1,1);    /* SARAM31 */
//
//    /* External-Memory */
//    GEL_MapAdd(0x028000,1,0x3D8000,1,1);    /* External-SDRAM */
//    GEL_MapAdd(0x400000,1,0x200000,1,1);    /* External-Async */
//    GEL_MapAdd(0x600000,1,0x100000,1,1);    /* External-Async */
//    GEL_MapAdd(0x700000,1,0x080000,1,1);    /* External-Async */
//    GEL_MapAdd(0x780000,1,0x070000,1,1);    /* External-Async */
//
//    /* ROM */
//    GEL_MapAdd(0x7F0000,1,0x004000,1,0);    /* SAROM0 */
//    GEL_MapAdd(0x7F4000,1,0x004000,1,0);    /* SAROM1 */
//    GEL_MapAdd(0x7F8000,1,0x004000,1,0);    /* SAROM2 */
//    GEL_MapAdd(0x7FC000,1,0x004000,1,0);    /* SAROM3 */
//
//    /* IO Space */
//    GEL_MapAdd(0x0000,2,0xFFFF,1,1);        /* XPORT */
//}

void Peripheral_Reset()
{
    int i;
   //�����������ü����Ĵ��� (PSRCR) ����ֵ��Ϊ 0x0020��ʮ���� 32������ζ�ŵ�������������ʱ�������źŽ����� 32 ��ϵͳʱ�� (SYSCLK) ���� ���û�ָ��Ҫ���ֵ��������Ϊ 08h ��ȷ��Ӳ���ܹ���ȷʶ�����ö��� ��
   //�������ÿ��ƼĴ��� (PRCR) �� ���ã���üĴ������ض�λд�� 1��������������Ӧ���������������
    *(volatile ioport Uint16 *)PSRCR = 0x0020;//*(short *)PSRCR@IO = 0x0020;
    *(volatile ioport Uint16 *)PRCR  = 0x00BB;//*(short *)PRCR@IO  = 0x00BB;

    for(i=0;i<0xff;i++);
    *(volatile ioport Uint16 *)IVPD = 0x027F;//*(short *)IVPD@data = 0x027F; // Load interrupt vector pointer
    //GEL_TextOut("Reset Peripherals is complete.\n");
}

void ProgramPLL_100MHz() {
    int i;

    //GEL_TextOut("Configuring PLL (100.00 MHz).\n");
    /* Enable clocks to all peripherals */
    *(volatile ioport Uint16 *)PCGCR1 = 0x0;//*(short *)PCGCR1@IO = 0x0;
    *(volatile ioport Uint16 *)PCGCR2 = 0x0;//*(short *)PCGCR2@IO = 0x0;

    /* Bypass PLL */
    *(volatile ioport Uint16 *)CCR2 = 0x0;//*(short *)CCR2@IO = 0x0;

    /* Set CLR_CNTL = 0 */
    *(volatile ioport Uint16 *)CGCR1 = *(volatile ioport Uint16 *)CGCR1 & 0x7FFF;//*(short *)CGCR1@IO = *(short *)CGCR1@IO & 0x7FFF;

    *(volatile ioport Uint16 *)CGCR1 =  0x8BE8;//*(short *)CGCR1@IO =  0x8BE8;
    *(volatile ioport Uint16 *)CGCR2 =  0x8000;//*(short *)CGCR2@IO =  0x8000;
    *(volatile ioport Uint16 *)CGCR3 =  0x0806;//*(short *)CGCR3@IO =  0x0806;
    *(volatile ioport Uint16 *)CGCR4 =  0x0000;//*(short *)CGCR4@IO =  0x0000;

    /* Wait for PLL lock */
    for(i=0;i<0x7fff;i++);

    /* Switch to PLL clk */
    *(volatile ioport Uint16 *)CCR2 = 0x1;//*(short *)CCR2@IO = 0x1;

//    GEL_TextOut("PLL Init Done.\n");

}

/* mSDRAM = MT48H4M16LF-8 */
/* Timings based on EMIF clk = 100MHz */

void SDRAM_INIT()
{
    int i;

    /* reset EMIF */
    *(volatile ioport Uint16 *)PRCR = 0x0002;//*(short *)PRCR@IO = 0x0002;
    for(i=0;i<0xff;i++);

    //enable SDRAM clock
    *(volatile ioport Uint16 *)CLKCFGL = 0x0001;//*(short*)CLKCFGL@IO=0x0001;

	/* enable word writes to EMIF regs */
    *(volatile ioport Uint16 *)ESCR = 0;//*(short *)ESCR@IO = 0;

    /* step 1 */
    *(volatile ioport Uint16 *)SDTIMR1 = 0x4710;//*(short *)SDTIMR1@IO = 0x4710;
    *(volatile ioport Uint16 *)SDTIMR2 = 0x3911;//*(short *)SDTIMR2@IO = 0x3911;
    *(volatile ioport Uint16 *)SDSRETR = 0x0007;//*(short *)SDSRETR@IO = 0x0007;

    /* step 2 */
    *(volatile ioport Uint16 *)SDRCR = 0x04E3;//*(short *)SDRCR@IO = 0x04E3;

    /* step 3 */
    *(volatile ioport Uint16 *)SDCR1 = 0x4720;//*(short *)SDCR1@IO = 0x4720;
    *(volatile ioport Uint16 *)SDCR2 = 0x0001;//*(short *)SDCR2@IO = 0x0001;

    /* step 4 */
    for(i=0;i<0xff;i++);

    /* step 5 */
    *(volatile ioport Uint16 *)SDRCR = 0x061A;//*(short *)SDRCR@IO = 0x061A;

    //GEL_TextOut("SDRAM Initialization Complete.\n");
}
