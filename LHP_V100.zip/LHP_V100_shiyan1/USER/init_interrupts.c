#include "init_interrupts.h"
#include "common.h"
#include "cslr.h"
#include "Hwi.h"

/* extern ISR declarations (these are provided elsewhere in the project) */
extern void USBisr(void);
extern void mmcsd0_isr(void);
extern void dma_isr(void);

/* If the project does not provide an HWI_unused handler, provide a
 * minimal stub so the linker can resolve the symbol. Replace or
 * remove this stub if a real handler is present elsewhere.
 */
void HWI_unused(void)
{
    /* minimal ISR stub: return immediately */
    asm(" NOP");
    return;
}


// �жϺŶ���
#define INT_NUM_MMCS0   5
#define INT_NUM_MMCSD1  7
#define INT_NUM_DMA     8
#define INT_NUM_USB     20
CSL_IRQ_Dispatch  dispatchTable[32];
// ���ú������ж�
void init_interrupts() {
    // 1. ��ʼ�� IRQ ģ��
	CSL_Status status;
	status = IRQ_init(dispatchTable, 1);
	if (status != CSL_SOK) {
		// ������ʼ��ʧ�ܵ����
		return;
    }
	    extern void VECSTART(void);
		IRQ_setVecs((Uint32)&VECSTART);

//	/* Map MMCSD/PROG events to mmcsd0_isr */
	IRQ_plug(PROG0_EVENT, mmcsd0_isr);
	IRQ_plug(PROG1_EVENT, mmcsd0_isr);
	IRQ_plug(PROG2_EVENT, mmcsd0_isr);
	/* Map DMA event to dma_isr (if used) */
	IRQ_plug(DMA_EVENT, dma_isr);
	/* Map USB event to USBisr */
	IRQ_plug(USB_EVENT, USBisr);


    IRQ_clear(PROG0_EVENT);
	IRQ_clear(PROG1_EVENT);
	IRQ_clear(PROG2_EVENT);
	IRQ_clear(DMA_EVENT);
	IRQ_clear(USB_EVENT);

    // 3. ʹ�ܾ�����ж�ͨ��
    IRQ_enable(PROG0_EVENT);
    IRQ_enable(USB_EVENT);
    IRQ_enable(DMA_EVENT);

    // 4. ȫ���ж�ʹ�ܣ���� BIOS ��û���㿪�Ļ���
    IRQ_globalEnable();
}


//
//void early_hardware_and_interrupt_init(void)
//{
//
//
//	/* 2) Register HWI using BIOS API (Hwi_create). This preserves dispatcher behavior
//	 * equivalent to useDispatcher=1 in the .tcf configuration.
//	 */
//	 {
//		            extern void VECSTART(void);
//		 			IRQ_globalDisable();
//		 			IRQ_setVecs((Uint32)&VECSTART);
//			/* Use HWI_dispatchPlug directly - this is the proven working method.
//					 * IRQ_plug uses a dispatch table mechanism that doesn't work correctly
//					 * for USB interrupt in this setup. HWI_dispatchPlug directly writes
//					 * the vector table and sets IER mask correctly. */
//					HWI_Attrs attrs;
//					attrs = HWI_ATTRS;
//					attrs.ier0mask = 0x0000;
//					attrs.ier1mask = 0x0010;
//					HWI_dispatchPlug(20, (Fxn)USBisr, &attrs);
//
//		 		/* If write failed, vector table may be in ROM or protected memory
//				 * Use CSL IRQ APIs as alternative to HWI_dispatchPlug */
////				CSL_Status status;
////				CSL_IRQ_Dispatch dispatchTable[IRQ_EVENT_CNT];  /* Dispatch table for all events */
////				CSL_IRQ_Config usbConfig;
////
////				/* Initialize INTC module with dispatch table */
////				status = IRQ_init(dispatchTable, 1);  /* biosPresent = 1 for DSP/BIOS */
////				if (status == CSL_SOK) {
////					/* Configure USB interrupt: set ISR function and IER1 mask 0x0010 */
////					usbConfig.funcAddr = USBisr;
////					usbConfig.funcArg = 0;
////					usbConfig.ierMask = 0x0010;  /* IER1 bit 4 for USB (Event 20) */
////					usbConfig.cacheCtrl = 0;
////
////					status = IRQ_config(USB_EVENT, &usbConfig);
////					if (status == CSL_SOK) {
////						/* Enable USB interrupt at CPU level */
////						IRQ_enable(USB_EVENT);
////					}
////				}
//
//
//			    IRQ_globalEnable();
//
//				/* Clear any pending USB interrupt flags */
//				IRQ_clear(USB_EVENT);
//
//
//
//	        /* Map MMCSD/PROG events to mmcsd0_isr */
//	        IRQ_plug(PROG0_EVENT, mmcsd0_isr);
//	        IRQ_plug(PROG1_EVENT, mmcsd0_isr);
//	        IRQ_plug(PROG2_EVENT, mmcsd0_isr);
////
////	        /* Map DMA event to dma_isr (if used) */
//	        IRQ_plug(DMA_EVENT, dma_isr);
//
//	        /* Clear any pending flags for these events (safe to do here) */
//	        IRQ_clear(PROG0_EVENT);
//	        IRQ_clear(PROG1_EVENT);
//	        IRQ_clear(PROG2_EVENT);
//	        IRQ_clear(DMA_EVENT);
//
//	 }
////	/* 3) Clear IFR groups (clear pending flags) */
////	CSL_CPU_REGS->IFR1 = 0x0;
//
//}

//void early_hardware_and_interrupt_init(void)
//{
//
//
//	/* 2) Register HWI using BIOS API (Hwi_create). This preserves dispatcher behavior
//	 * equivalent to useDispatcher=1 in the .tcf configuration.
//	 */
//	 {
//		   // IRQ_setVecs((Uint32)0x027e00);
////		    /* Use DSP/BIOS HWI API to plug handlers and set per-HWI attributes
////			 * to match the .tcf configuration (ier0/ier1 masks).
////			 */
////     		HWI_Attrs attrs;
////
////			/* INT5 (vector 5) : mmcsd0_isr, IER0 mask 0x0020 */
////			attrs = HWI_ATTRS;
////			attrs.ier0mask = 0x0020;
////			attrs.ier1mask = 0x0000;
////			HWI_dispatchPlug(5, (Fxn)mmcsd0_isr, &attrs);
////
////			/* INT7 (vector 7) : mmcsd0_isr, IER0 mask 0x0080 */
////			attrs = HWI_ATTRS;
////			attrs.ier0mask = 0x0080;
////			attrs.ier1mask = 0x0000;
////			HWI_dispatchPlug(7, (Fxn)mmcsd0_isr, &attrs);
////
////			/* INT8 (vector 8) : dma_isr, IER0 mask 0x0100 */
////			attrs = HWI_ATTRS;
////			attrs.ier0mask = 0x0100;
////			attrs.ier1mask = 0x0000;
////			HWI_dispatchPlug(8, (Fxn)dma_isr, &attrs);
////
////			/* INT9 (vector 9) : mmcsd0_isr, IER0 mask 0x0020 */
////			attrs = HWI_ATTRS;
////			attrs.ier0mask = 0x0020;
////			attrs.ier1mask = 0x0000;
////			HWI_dispatchPlug(9, (Fxn)mmcsd0_isr, &attrs);
////
////			/* INT12: unused stub (keep default attrs) */
////			attrs = HWI_ATTRS;
////			HWI_dispatchPlug(12, (Fxn)HWI_unused, &attrs);
////
//			/* INT20 (vector 20) : USB ISR, IER1 mask 0x0010 */
////			attrs = HWI_ATTRS;
////			attrs.ier0mask = 0x0000;
////			attrs.ier1mask = 0x0010;
////			HWI_dispatchPlug(20, (Fxn)USBisr, &attrs);
//	        /* Map MMCSD/PROG events to mmcsd0_isr */
//	        IRQ_plug(PROG0_EVENT, mmcsd0_isr);
//	        IRQ_plug(PROG1_EVENT, mmcsd0_isr);
//	        IRQ_plug(PROG2_EVENT, mmcsd0_isr);
//
//	        /* Map DMA event to dma_isr (if used) */
//	        IRQ_plug(DMA_EVENT, dma_isr);
//
////	        /* Map USB event to USBisr */
////	        IRQ_plug(USB_EVENT, USBisr);
//
//	        /* Clear any pending flags for these events (safe to do here) */
//	        IRQ_clear(PROG0_EVENT);
//	        IRQ_clear(PROG1_EVENT);
//	        IRQ_clear(PROG2_EVENT);
//	        IRQ_clear(DMA_EVENT);
////	        IRQ_clear(USB_EVENT);
//
//
//	 }
////	/* 3) Clear IFR groups (clear pending flags) */
////	CSL_CPU_REGS->IFR1 = 0x0;
//
//}


