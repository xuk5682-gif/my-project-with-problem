#ifndef INIT_INTERRUPTS_H
#define INIT_INTERRUPTS_H

/* Early hardware and interrupt initialization to replace .tcf HWI entries.
 * Call early_hardware_and_interrupt_init() as the first action in main()
 * (before USB/MMC/DMA initialization).
 */
void early_hardware_and_interrupt_init(void);
void init_interrupts();
#endif /* INIT_INTERRUPTS_H */


