/********************************************************************/
/* evm5515.gel                                                    */
/* Version 0.02                                                     */
/*                                                                  */
/* This GEL file is to be used with the 5515 EVM.                 */
/* Changes may be required to support specific hardware designs.    */
/*                                                                  */
/* Code Composer Studio supports six reserved GEL functions that    */
/* automatically get executed if they are defined. They are:        */
/*                                                                  */
/* StartUp()              - Executed whenever CCS is invoked        */
/* OnReset()              - Executed after Debug->Reset CPU         */
/* OnRestart()            - Executed after Debug->Restart           */
/* OnPreFileLoaded()      - Executed before File->Load Program      */
/* OnFileLoaded()         - Executed after File->Load Program       */
/* OnTargetConnect()      - Executed after Debug->Connect           */
/*                                                                  */
/*   Version History                                                */
/*     v0.01        Initial Release                                 */
/*     v0.02        Corrected PLL settings                          */
/********************************************************************/

void OnTargetConnect();

void OnRestart();

#define ESCR     0x1c33

#define SDTIMR1  0x1020
#define SDTIMR2  0x1021
#define SDCR1    0x1008
#define SDCR2    0x1009
#define SDSRETR  0x103C
#define SDRCR    0x100C

#define PRCR     0x1C05
#define PCGCR1   0x1c02
#define PCGCR2   0x1c03
#define PSRCR    0x1c04

#define CLKCFGL  0x1c1e
#define CCR2     0x1c1f
#define CGCR1    0x1c20
#define CGCR2    0x1c21
#define CGCR3    0x1c22
#define CGCR4    0x1c23
#define CCSSR    0x1c24
#define IVPD     0x0049


// ***************************************************************************



void Peripheral_Reset();


void ProgramPLL_100MHz() ;

/* mSDRAM = MT48H4M16LF-8 */
/* Timings based on EMIF clk = 100MHz */

void SDRAM_INIT();
