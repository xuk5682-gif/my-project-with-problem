# FIXED

TASK/FFT/fft_task.obj: ../TASK/FFT/fft_task.c
TASK/FFT/fft_task.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/std.h
TASK/FFT/fft_task.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/tistdtypes.h
TASK/FFT/fft_task.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/sem.h
TASK/FFT/fft_task.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/knl.h
TASK/FFT/fft_task.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/atm.h
TASK/FFT/fft_task.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/fxn.h
TASK/FFT/fft_task.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/que.h
TASK/FFT/fft_task.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/mem.h
TASK/FFT/fft_task.obj: F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stddef.h
TASK/FFT/fft_task.obj: F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stdarg.h
TASK/FFT/fft_task.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/sts.h
TASK/FFT/fft_task.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/swi.h
TASK/FFT/fft_task.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/hwi.h
TASK/FFT/fft_task.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/obj.h
TASK/FFT/fft_task.obj: F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stddef.h
TASK/FFT/fft_task.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/sys.h
TASK/FFT/fft_task.obj: F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stdarg.h
TASK/FFT/fft_task.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/tsk.h
TASK/FFT/fft_task.obj: F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stdarg.h
TASK/FFT/fft_task.obj: F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stddef.h
TASK/FFT/fft_task.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/prd.h
TASK/FFT/fft_task.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/trg.h
TASK/FFT/fft_task.obj: F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stddef.h
TASK/FFT/fft_task.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/_hook.h
TASK/FFT/fft_task.obj: F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/string.h
TASK/FFT/fft_task.obj: F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/linkage.h
TASK/FFT/fft_task.obj: C:/ti_c55_lp/c55_dsplib_3.00/c55_dsplib_03.00.00.03/include/stdio.h
TASK/FFT/fft_task.obj: ../TASK/FFT/fft_task.h
TASK/FFT/fft_task.obj: C:/ti/CCS_Project/c55_csl_3.08.01/ccs_v6.x_examples/usb/LHP_V100_shiyan1/BSP/ADS127L11/ads127l11.h
TASK/FFT/fft_task.obj: F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stdint.h
TASK/FFT/fft_task.obj: F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stdbool.h
TASK/FFT/fft_task.obj: F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/yvals.h
TASK/FFT/fft_task.obj: F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stdarg.h
TASK/FFT/fft_task.obj: F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/_lock.h
TASK/FFT/fft_task.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_gpio.h
TASK/FFT/fft_task.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr.h
TASK/FFT/fft_task.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/soc.h
TASK/FFT/fft_task.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_general.h
TASK/FFT/fft_task.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_cpu.h
TASK/FFT/fft_task.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_sysctrl.h
TASK/FFT/fft_task.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_i2c.h
TASK/FFT/fft_task.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_i2s.h
TASK/FFT/fft_task.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_emif.h
TASK/FFT/fft_task.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_uart.h
TASK/FFT/fft_task.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_spi.h
TASK/FFT/fft_task.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_mmcsd.h
TASK/FFT/fft_task.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_lcdc.h
TASK/FFT/fft_task.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_rtc.h
TASK/FFT/fft_task.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_dma.h
TASK/FFT/fft_task.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_sar.h
TASK/FFT/fft_task.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_usb.h
TASK/FFT/fft_task.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_gpio.h
TASK/FFT/fft_task.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_tim.h
TASK/FFT/fft_task.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_wdt.h
TASK/FFT/fft_task.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_idle.h
TASK/FFT/fft_task.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_ldo.h
TASK/FFT/fft_task.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_mcbsp.h
TASK/FFT/fft_task.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_mcspi.h
TASK/FFT/fft_task.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_uhpi.h
TASK/FFT/fft_task.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_error.h
TASK/FFT/fft_task.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_types.h

../TASK/FFT/fft_task.c:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/std.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/tistdtypes.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/sem.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/knl.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/atm.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/fxn.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/que.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/mem.h:

F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stddef.h:

F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stdarg.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/sts.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/swi.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/hwi.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/obj.h:

F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stddef.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/sys.h:

F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stdarg.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/tsk.h:

F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stdarg.h:

F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stddef.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/prd.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/trg.h:

F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stddef.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/_hook.h:

F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/string.h:

F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/linkage.h:

C:/ti_c55_lp/c55_dsplib_3.00/c55_dsplib_03.00.00.03/include/stdio.h:

../TASK/FFT/fft_task.h:

C:/ti/CCS_Project/c55_csl_3.08.01/ccs_v6.x_examples/usb/LHP_V100_shiyan1/BSP/ADS127L11/ads127l11.h:

F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stdint.h:

F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stdbool.h:

F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/yvals.h:

F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stdarg.h:

F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/_lock.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_gpio.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/soc.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_general.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_cpu.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_sysctrl.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_i2c.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_i2s.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_emif.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_uart.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_spi.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_mmcsd.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_lcdc.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_rtc.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_dma.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_sar.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_usb.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_gpio.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_tim.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_wdt.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_idle.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_ldo.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_mcbsp.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_mcspi.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_uhpi.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_error.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_types.h:

