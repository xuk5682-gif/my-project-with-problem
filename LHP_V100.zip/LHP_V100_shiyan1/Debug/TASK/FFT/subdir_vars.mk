################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../TASK/FFT/fft_task.c 

C_DEPS += \
./TASK/FFT/fft_task.d 

OBJS += \
./TASK/FFT/fft_task.obj 

OBJS__QUOTED += \
"TASK\FFT\fft_task.obj" 

C_DEPS__QUOTED += \
"TASK\FFT\fft_task.d" 

C_SRCS__QUOTED += \
"../TASK/FFT/fft_task.c" 


