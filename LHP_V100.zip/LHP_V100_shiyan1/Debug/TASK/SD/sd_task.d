# FIXED

TASK/SD/sd_task.obj: ../TASK/SD/sd_task.c
TASK/SD/sd_task.obj: ../TASK/SD/sd_task.h
TASK/SD/sd_task.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_types.h
TASK/SD/sd_task.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/tistdtypes.h
TASK/SD/sd_task.obj: C:/ti/CCS_Project/c55_csl_3.08.01/ccs_v6.x_examples/usb/LHP_V100_shiyan1/BSP/USB_MSC_dma/common.h
TASK/SD/sd_task.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/log.h
TASK/SD/sd_task.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/_log.h
TASK/SD/sd_task.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/std.h
TASK/SD/sd_task.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/trc.h
TASK/SD/sd_task.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/mbx.h
TASK/SD/sd_task.obj: F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stddef.h
TASK/SD/sd_task.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/que.h
TASK/SD/sd_task.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/fxn.h
TASK/SD/sd_task.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/mem.h
TASK/SD/sd_task.obj: F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stddef.h
TASK/SD/sd_task.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/sem.h
TASK/SD/sd_task.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/knl.h
TASK/SD/sd_task.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/atm.h
TASK/SD/sd_task.obj: F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stdarg.h
TASK/SD/sd_task.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/sts.h
TASK/SD/sd_task.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/swi.h
TASK/SD/sd_task.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/hwi.h
TASK/SD/sd_task.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/obj.h
TASK/SD/sd_task.obj: F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stddef.h
TASK/SD/sd_task.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/sys.h
TASK/SD/sd_task.obj: F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stdarg.h
TASK/SD/sd_task.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/tsk.h
TASK/SD/sd_task.obj: F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stdarg.h
TASK/SD/sd_task.obj: F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stddef.h
TASK/SD/sd_task.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/prd.h
TASK/SD/sd_task.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/trg.h
TASK/SD/sd_task.obj: F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stddef.h
TASK/SD/sd_task.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/_hook.h
TASK/SD/sd_task.obj: F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stdlib.h
TASK/SD/sd_task.obj: F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/linkage.h
TASK/SD/sd_task.obj: C:/ti_c55_lp/c55_dsplib_3.00/c55_dsplib_03.00.00.03/include/stdio.h
TASK/SD/sd_task.obj: F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/string.h
TASK/SD/sd_task.obj: C:/ti/CCS_Project/c55_csl_3.08.01/ccs_v6.x_examples/usb/LHP_V100_shiyan1/BSP/UART/uart.h
TASK/SD/sd_task.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_uart.h
TASK/SD/sd_task.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr.h
TASK/SD/sd_task.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_error.h
TASK/SD/sd_task.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_uart.h
TASK/SD/sd_task.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_general.h
TASK/SD/sd_task.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/soc.h
TASK/SD/sd_task.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_cpu.h
TASK/SD/sd_task.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_sysctrl.h
TASK/SD/sd_task.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_i2c.h
TASK/SD/sd_task.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_i2s.h
TASK/SD/sd_task.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_emif.h
TASK/SD/sd_task.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_spi.h
TASK/SD/sd_task.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_mmcsd.h
TASK/SD/sd_task.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_lcdc.h
TASK/SD/sd_task.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_rtc.h
TASK/SD/sd_task.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_dma.h
TASK/SD/sd_task.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_sar.h
TASK/SD/sd_task.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_usb.h
TASK/SD/sd_task.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_gpio.h
TASK/SD/sd_task.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_tim.h
TASK/SD/sd_task.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_wdt.h
TASK/SD/sd_task.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_idle.h
TASK/SD/sd_task.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_ldo.h
TASK/SD/sd_task.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_mcbsp.h
TASK/SD/sd_task.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_mcspi.h
TASK/SD/sd_task.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_uhpi.h
TASK/SD/sd_task.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_intc.h
TASK/SD/sd_task.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_uartAux.h
TASK/SD/sd_task.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_sysctrl.h
TASK/SD/sd_task.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_pll.h
TASK/SD/sd_task.obj: F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stdarg.h
TASK/SD/sd_task.obj: C:/ti/CCS_Project/c55_csl_3.08.01/ccs_v6.x_examples/usb/LHP_V100_shiyan1/BSP/USB_MSC_dma/msc_media.h
TASK/SD/sd_task.obj: C:/ti/CCS_Project/c55_csl_3.08.01/ccs_v6.x_examples/drv/atafs/src/ata_.h
TASK/SD/sd_task.obj: C:/ti/CCS_Project/c55_csl_3.08.01/ccs_v6.x_examples/drv/atafs/src/ata.h
TASK/SD/sd_task.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_msc.h
TASK/SD/sd_task.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_usb.h
TASK/SD/sd_task.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_mmcsd_ataIf.h
TASK/SD/sd_task.obj: C:/ti/CCS_Project/c55_csl_3.08.01/ccs_v6.x_examples/usb/LHP_V100_shiyan1/BSP/SD/sd_card.h
TASK/SD/sd_task.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_mmcsd.h
TASK/SD/sd_task.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_dma.h
TASK/SD/sd_task.obj: C:/ti/CCS_Project/c55_csl_3.08.01/ccs_v6.x_examples/usb/LHP_V100_shiyan1/BSP/UART/uart.h
TASK/SD/sd_task.obj: F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stdarg.h
TASK/SD/sd_task.obj: F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/string.h
TASK/SD/sd_task.obj: F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/errno.h
TASK/SD/sd_task.obj: C:/ti/CCS_Project/c55_csl_3.08.01/ccs_v6.x_examples/usb/LHP_V100_shiyan1/BSP/ADS127L11/ads127l11.h
TASK/SD/sd_task.obj: F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stdint.h
TASK/SD/sd_task.obj: F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stdbool.h
TASK/SD/sd_task.obj: F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/yvals.h
TASK/SD/sd_task.obj: F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stdarg.h
TASK/SD/sd_task.obj: F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/_lock.h
TASK/SD/sd_task.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_gpio.h

../TASK/SD/sd_task.c:

../TASK/SD/sd_task.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_types.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/tistdtypes.h:

C:/ti/CCS_Project/c55_csl_3.08.01/ccs_v6.x_examples/usb/LHP_V100_shiyan1/BSP/USB_MSC_dma/common.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/log.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/_log.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/std.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/trc.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/mbx.h:

F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stddef.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/que.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/fxn.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/mem.h:

F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stddef.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/sem.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/knl.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/atm.h:

F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stdarg.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/sts.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/swi.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/hwi.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/obj.h:

F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stddef.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/sys.h:

F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stdarg.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/tsk.h:

F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stdarg.h:

F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stddef.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/prd.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/trg.h:

F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stddef.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/_hook.h:

F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stdlib.h:

F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/linkage.h:

C:/ti_c55_lp/c55_dsplib_3.00/c55_dsplib_03.00.00.03/include/stdio.h:

F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/string.h:

C:/ti/CCS_Project/c55_csl_3.08.01/ccs_v6.x_examples/usb/LHP_V100_shiyan1/BSP/UART/uart.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_uart.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_error.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_uart.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_general.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/soc.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_cpu.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_sysctrl.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_i2c.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_i2s.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_emif.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_spi.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_mmcsd.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_lcdc.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_rtc.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_dma.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_sar.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_usb.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_gpio.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_tim.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_wdt.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_idle.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_ldo.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_mcbsp.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_mcspi.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_uhpi.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_intc.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_uartAux.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_sysctrl.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_pll.h:

F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stdarg.h:

C:/ti/CCS_Project/c55_csl_3.08.01/ccs_v6.x_examples/usb/LHP_V100_shiyan1/BSP/USB_MSC_dma/msc_media.h:

C:/ti/CCS_Project/c55_csl_3.08.01/ccs_v6.x_examples/drv/atafs/src/ata_.h:

C:/ti/CCS_Project/c55_csl_3.08.01/ccs_v6.x_examples/drv/atafs/src/ata.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_msc.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_usb.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_mmcsd_ataIf.h:

C:/ti/CCS_Project/c55_csl_3.08.01/ccs_v6.x_examples/usb/LHP_V100_shiyan1/BSP/SD/sd_card.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_mmcsd.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_dma.h:

C:/ti/CCS_Project/c55_csl_3.08.01/ccs_v6.x_examples/usb/LHP_V100_shiyan1/BSP/UART/uart.h:

F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stdarg.h:

F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/string.h:

F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/errno.h:

C:/ti/CCS_Project/c55_csl_3.08.01/ccs_v6.x_examples/usb/LHP_V100_shiyan1/BSP/ADS127L11/ads127l11.h:

F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stdint.h:

F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stdbool.h:

F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/yvals.h:

F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stdarg.h:

F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/_lock.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_gpio.h:

