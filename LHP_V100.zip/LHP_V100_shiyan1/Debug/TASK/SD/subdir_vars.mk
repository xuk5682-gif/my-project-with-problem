################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../TASK/SD/sd_task.c 

C_DEPS += \
./TASK/SD/sd_task.d 

OBJS += \
./TASK/SD/sd_task.obj 

OBJS__QUOTED += \
"TASK\SD\sd_task.obj" 

C_DEPS__QUOTED += \
"TASK\SD\sd_task.d" 

C_SRCS__QUOTED += \
"../TASK/SD/sd_task.c" 


