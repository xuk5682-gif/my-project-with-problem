################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../TASK/UART/uart_task.c 

C_DEPS += \
./TASK/UART/uart_task.d 

OBJS += \
./TASK/UART/uart_task.obj 

OBJS__QUOTED += \
"TASK\UART\uart_task.obj" 

C_DEPS__QUOTED += \
"TASK\UART\uart_task.d" 

C_SRCS__QUOTED += \
"../TASK/UART/uart_task.c" 


