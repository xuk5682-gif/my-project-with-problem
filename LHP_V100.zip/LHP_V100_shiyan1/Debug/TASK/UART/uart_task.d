# FIXED

TASK/UART/uart_task.obj: ../TASK/UART/uart_task.c

../TASK/UART/uart_task.c:

