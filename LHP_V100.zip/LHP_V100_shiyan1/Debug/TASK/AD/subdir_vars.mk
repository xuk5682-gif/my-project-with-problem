################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../TASK/AD/ad_task.c 

C_DEPS += \
./TASK/AD/ad_task.d 

OBJS += \
./TASK/AD/ad_task.obj 

OBJS__QUOTED += \
"TASK\AD\ad_task.obj" 

C_DEPS__QUOTED += \
"TASK\AD\ad_task.d" 

C_SRCS__QUOTED += \
"../TASK/AD/ad_task.c" 


