################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../BSP/SD/sd_card.c \
../BSP/SD/sd_handler.c 

C_DEPS += \
./BSP/SD/sd_card.d \
./BSP/SD/sd_handler.d 

OBJS += \
./BSP/SD/sd_card.obj \
./BSP/SD/sd_handler.obj 

OBJS__QUOTED += \
"BSP\SD\sd_card.obj" \
"BSP\SD\sd_handler.obj" 

C_DEPS__QUOTED += \
"BSP\SD\sd_card.d" \
"BSP\SD\sd_handler.d" 

C_SRCS__QUOTED += \
"../BSP/SD/sd_card.c" \
"../BSP/SD/sd_handler.c" 


