# FIXED

BSP/ADS127L11/ads127l11.obj: ../BSP/ADS127L11/ads127l11.c
BSP/ADS127L11/ads127l11.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/std.h
BSP/ADS127L11/ads127l11.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/tistdtypes.h
BSP/ADS127L11/ads127l11.obj: ../BSP/ADS127L11/ads127l11.h
BSP/ADS127L11/ads127l11.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/sem.h
BSP/ADS127L11/ads127l11.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/knl.h
BSP/ADS127L11/ads127l11.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/atm.h
BSP/ADS127L11/ads127l11.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/fxn.h
BSP/ADS127L11/ads127l11.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/que.h
BSP/ADS127L11/ads127l11.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/mem.h
BSP/ADS127L11/ads127l11.obj: F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stddef.h
BSP/ADS127L11/ads127l11.obj: F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stdarg.h
BSP/ADS127L11/ads127l11.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/sts.h
BSP/ADS127L11/ads127l11.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/swi.h
BSP/ADS127L11/ads127l11.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/hwi.h
BSP/ADS127L11/ads127l11.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/obj.h
BSP/ADS127L11/ads127l11.obj: F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stddef.h
BSP/ADS127L11/ads127l11.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/sys.h
BSP/ADS127L11/ads127l11.obj: F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stdarg.h
BSP/ADS127L11/ads127l11.obj: F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stdint.h
BSP/ADS127L11/ads127l11.obj: F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stdbool.h
BSP/ADS127L11/ads127l11.obj: F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/yvals.h
BSP/ADS127L11/ads127l11.obj: F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stdarg.h
BSP/ADS127L11/ads127l11.obj: F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/linkage.h
BSP/ADS127L11/ads127l11.obj: F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/_lock.h
BSP/ADS127L11/ads127l11.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_gpio.h
BSP/ADS127L11/ads127l11.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr.h
BSP/ADS127L11/ads127l11.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/soc.h
BSP/ADS127L11/ads127l11.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_general.h
BSP/ADS127L11/ads127l11.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_cpu.h
BSP/ADS127L11/ads127l11.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_sysctrl.h
BSP/ADS127L11/ads127l11.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_i2c.h
BSP/ADS127L11/ads127l11.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_i2s.h
BSP/ADS127L11/ads127l11.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_emif.h
BSP/ADS127L11/ads127l11.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_uart.h
BSP/ADS127L11/ads127l11.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_spi.h
BSP/ADS127L11/ads127l11.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_mmcsd.h
BSP/ADS127L11/ads127l11.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_lcdc.h
BSP/ADS127L11/ads127l11.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_rtc.h
BSP/ADS127L11/ads127l11.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_dma.h
BSP/ADS127L11/ads127l11.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_sar.h
BSP/ADS127L11/ads127l11.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_usb.h
BSP/ADS127L11/ads127l11.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_gpio.h
BSP/ADS127L11/ads127l11.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_tim.h
BSP/ADS127L11/ads127l11.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_wdt.h
BSP/ADS127L11/ads127l11.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_idle.h
BSP/ADS127L11/ads127l11.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_ldo.h
BSP/ADS127L11/ads127l11.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_mcbsp.h
BSP/ADS127L11/ads127l11.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_mcspi.h
BSP/ADS127L11/ads127l11.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_uhpi.h
BSP/ADS127L11/ads127l11.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_error.h
BSP/ADS127L11/ads127l11.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_types.h
BSP/ADS127L11/ads127l11.obj: C:/ti/CCS_Project/c55_csl_3.08.01/ccs_v6.x_examples/usb/LHP_V100_shiyan1/BSP/PLL/PLL_SetSysClk.h
BSP/ADS127L11/ads127l11.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_pll.h
BSP/ADS127L11/ads127l11.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_sysctrl.h
BSP/ADS127L11/ads127l11.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_spi.h
BSP/ADS127L11/ads127l11.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_intc.h
BSP/ADS127L11/ads127l11.obj: C:/ti/CCS_Project/c55_csl_3.08.01/ccs_v6.x_examples/usb/LHP_V100_shiyan1/BSP/USB_MSC_dma/common.h
BSP/ADS127L11/ads127l11.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/log.h
BSP/ADS127L11/ads127l11.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/_log.h
BSP/ADS127L11/ads127l11.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/trc.h
BSP/ADS127L11/ads127l11.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/mbx.h
BSP/ADS127L11/ads127l11.obj: F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stddef.h
BSP/ADS127L11/ads127l11.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/tsk.h
BSP/ADS127L11/ads127l11.obj: F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stdarg.h
BSP/ADS127L11/ads127l11.obj: F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stddef.h
BSP/ADS127L11/ads127l11.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/prd.h
BSP/ADS127L11/ads127l11.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/trg.h
BSP/ADS127L11/ads127l11.obj: F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stddef.h
BSP/ADS127L11/ads127l11.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/_hook.h
BSP/ADS127L11/ads127l11.obj: F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stdlib.h
BSP/ADS127L11/ads127l11.obj: C:/ti_c55_lp/c55_dsplib_3.00/c55_dsplib_03.00.00.03/include/stdio.h
BSP/ADS127L11/ads127l11.obj: F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/string.h
BSP/ADS127L11/ads127l11.obj: C:/ti/CCS_Project/c55_csl_3.08.01/ccs_v6.x_examples/usb/LHP_V100_shiyan1/BSP/UART/uart.h
BSP/ADS127L11/ads127l11.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_uart.h
BSP/ADS127L11/ads127l11.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_uartAux.h
BSP/ADS127L11/ads127l11.obj: F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stdarg.h
BSP/ADS127L11/ads127l11.obj: F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/string.h
BSP/ADS127L11/ads127l11.obj: F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stddef.h

../BSP/ADS127L11/ads127l11.c:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/std.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/tistdtypes.h:

../BSP/ADS127L11/ads127l11.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/sem.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/knl.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/atm.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/fxn.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/que.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/mem.h:

F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stddef.h:

F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stdarg.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/sts.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/swi.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/hwi.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/obj.h:

F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stddef.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/sys.h:

F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stdarg.h:

F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stdint.h:

F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stdbool.h:

F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/yvals.h:

F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stdarg.h:

F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/linkage.h:

F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/_lock.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_gpio.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/soc.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_general.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_cpu.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_sysctrl.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_i2c.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_i2s.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_emif.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_uart.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_spi.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_mmcsd.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_lcdc.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_rtc.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_dma.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_sar.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_usb.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_gpio.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_tim.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_wdt.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_idle.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_ldo.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_mcbsp.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_mcspi.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_uhpi.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_error.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_types.h:

C:/ti/CCS_Project/c55_csl_3.08.01/ccs_v6.x_examples/usb/LHP_V100_shiyan1/BSP/PLL/PLL_SetSysClk.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_pll.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_sysctrl.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_spi.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_intc.h:

C:/ti/CCS_Project/c55_csl_3.08.01/ccs_v6.x_examples/usb/LHP_V100_shiyan1/BSP/USB_MSC_dma/common.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/log.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/_log.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/trc.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/mbx.h:

F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stddef.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/tsk.h:

F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stdarg.h:

F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stddef.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/prd.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/trg.h:

F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stddef.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/_hook.h:

F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stdlib.h:

C:/ti_c55_lp/c55_dsplib_3.00/c55_dsplib_03.00.00.03/include/stdio.h:

F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/string.h:

C:/ti/CCS_Project/c55_csl_3.08.01/ccs_v6.x_examples/usb/LHP_V100_shiyan1/BSP/UART/uart.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_uart.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_uartAux.h:

F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stdarg.h:

F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/string.h:

F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stddef.h:

