# FIXED

BSP/ADS127L11/spi_int.obj: ../BSP/ADS127L11/spi_int.c

../BSP/ADS127L11/spi_int.c:

