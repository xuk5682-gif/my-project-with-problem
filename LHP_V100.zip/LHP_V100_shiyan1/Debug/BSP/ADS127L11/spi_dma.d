# FIXED

BSP/ADS127L11/spi_dma.obj: ../BSP/ADS127L11/spi_dma.c

../BSP/ADS127L11/spi_dma.c:

