################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../BSP/ADS127L11/ADS127L11cpoy.c \
../BSP/ADS127L11/ads127l11.c \
../BSP/ADS127L11/spi_dma.c \
../BSP/ADS127L11/spi_int.c 

C_DEPS += \
./BSP/ADS127L11/ADS127L11cpoy.d \
./BSP/ADS127L11/ads127l11.d \
./BSP/ADS127L11/spi_dma.d \
./BSP/ADS127L11/spi_int.d 

OBJS += \
./BSP/ADS127L11/ADS127L11cpoy.obj \
./BSP/ADS127L11/ads127l11.obj \
./BSP/ADS127L11/spi_dma.obj \
./BSP/ADS127L11/spi_int.obj 

OBJS__QUOTED += \
"BSP\ADS127L11\ADS127L11cpoy.obj" \
"BSP\ADS127L11\ads127l11.obj" \
"BSP\ADS127L11\spi_dma.obj" \
"BSP\ADS127L11\spi_int.obj" 

C_DEPS__QUOTED += \
"BSP\ADS127L11\ADS127L11cpoy.d" \
"BSP\ADS127L11\ads127l11.d" \
"BSP\ADS127L11\spi_dma.d" \
"BSP\ADS127L11\spi_int.d" 

C_SRCS__QUOTED += \
"../BSP/ADS127L11/ADS127L11cpoy.c" \
"../BSP/ADS127L11/ads127l11.c" \
"../BSP/ADS127L11/spi_dma.c" \
"../BSP/ADS127L11/spi_int.c" 


