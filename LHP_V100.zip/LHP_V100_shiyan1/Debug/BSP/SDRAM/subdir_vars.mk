################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../BSP/SDRAM/sdram.c 

C_DEPS += \
./BSP/SDRAM/sdram.d 

OBJS += \
./BSP/SDRAM/sdram.obj 

OBJS__QUOTED += \
"BSP\SDRAM\sdram.obj" 

C_DEPS__QUOTED += \
"BSP\SDRAM\sdram.d" 

C_SRCS__QUOTED += \
"../BSP/SDRAM/sdram.c" 


