################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../BSP/UART/uart.c 

C_DEPS += \
./BSP/UART/uart.d 

OBJS += \
./BSP/UART/uart.obj 

OBJS__QUOTED += \
"BSP\UART\uart.obj" 

C_DEPS__QUOTED += \
"BSP\UART\uart.d" 

C_SRCS__QUOTED += \
"../BSP/UART/uart.c" 


