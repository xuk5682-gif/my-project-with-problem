################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../BSP/FFT/fft_task.c \
../BSP/FFT/fft_thread.c 

C_DEPS += \
./BSP/FFT/fft_task.d \
./BSP/FFT/fft_thread.d 

OBJS += \
./BSP/FFT/fft_task.obj \
./BSP/FFT/fft_thread.obj 

OBJS__QUOTED += \
"BSP\FFT\fft_task.obj" \
"BSP\FFT\fft_thread.obj" 

C_DEPS__QUOTED += \
"BSP\FFT\fft_task.d" \
"BSP\FFT\fft_thread.d" 

C_SRCS__QUOTED += \
"../BSP/FFT/fft_task.c" \
"../BSP/FFT/fft_thread.c" 


