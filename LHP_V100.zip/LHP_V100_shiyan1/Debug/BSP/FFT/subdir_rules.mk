################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Each subdirectory must supply rules for building sources it contributes
BSP/FFT/%.obj: ../BSP/FFT/%.c $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Building file: "$<"'
	@echo 'Invoking: C5500 Compiler'
	"F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/bin/cl55" -v5515 --memory_model=large -g --include_path="C:/ti/CCS_Project/c55_csl_3.08.01/ccs_v6.x_examples/usb/LHP_V100_shiyan1/USER" --include_path="C:/ti/CCS_Project/c55_csl_3.08.01/ccs_v6.x_examples/usb/LHP_V100_shiyan1/TASK/SD" --include_path="C:/ti/CCS_Project/c55_csl_3.08.01/ccs_v6.x_examples/usb/LHP_V100_shiyan1/TASK/AD" --include_path="C:/ti/CCS_Project/c55_csl_3.08.01/ccs_v6.x_examples/usb/LHP_V100_shiyan1/TASK/FFT" --include_path="C:/ti/CCS_Project/c55_csl_3.08.01/ccs_v6.x_examples/usb/LHP_V100_shiyan1/BSP/SD" --include_path="C:/ti/CCS_Project/c55_csl_3.08.01/ccs_v6.x_examples/usb/LHP_V100_shiyan1/BSP/PLL" --include_path="C:/ti/CCS_Project/c55_csl_3.08.01/ccs_v6.x_examples/usb/LHP_V100_shiyan1/BSP/SDRAM" --include_path="C:/ti_c55_lp/c55_dsplib_3.00/c55_dsplib_03.00.00.03/include" --include_path="F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include" --include_path="C:/ti/CCS_Project/c55_csl_3.08.01/ccs_v6.x_examples/usb/LHP_V100_shiyan1/BSP/USB_MSC_dma" --include_path="C:/ti/CCS_Project/c55_csl_3.08.01/ccs_v6.x_examples/usb/LHP_V100_shiyan1/BSP/UART" --include_path="C:/ti/CCS_Project/c55_csl_3.08.01/ccs_v6.x_examples/usb/LHP_V100_shiyan1/BSP/ADS127L11" --include_path="C:/ti/bios_5_42_02_10/packages/ti/bios/include" --include_path="C:/ti/CCS_Project/c55_csl_3.08.01/inc" --include_path="C:/ti/CCS_Project/c55_csl_3.08.01/ccs_v6.x_examples/drv/atafs/src" --include_path="C:/ti/CCS_Project/c55_csl_3.08.01/ccs_v6.x_examples/drv/common" --include_path="C:/ti/CCS_Project/c55_csl_3.08.01/ccs_v6.x_examples/usb/LHP_V100_shiyan1/Debug" --include_path="C:/ti/bios_5_42_02_10/packages/ti/rtdx/include/c5500" --define=_DEBUG --define=CSL_MSC_TEST --define=c5515 --display_error_number --verbose_diagnostics --diag_warning=225 --ptrdiff_size=16 --algebraic --asm_source=algebraic --preproc_with_compile --preproc_dependency="BSP/FFT/$(basename $(<F)).d_raw" --obj_directory="BSP/FFT" $(GEN_OPTS__FLAG) "$<"
	@echo 'Finished building: "$<"'
	@echo ' '


