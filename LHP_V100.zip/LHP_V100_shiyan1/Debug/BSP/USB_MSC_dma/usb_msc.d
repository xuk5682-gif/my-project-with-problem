# FIXED

BSP/USB_MSC_dma/usb_msc.obj: ../BSP/USB_MSC_dma/usb_msc.c
BSP/USB_MSC_dma/usb_msc.obj: ../BSP/USB_MSC_dma/usb_msc.h
BSP/USB_MSC_dma/usb_msc.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_usb.h
BSP/USB_MSC_dma/usb_msc.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr.h
BSP/USB_MSC_dma/usb_msc.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_error.h
BSP/USB_MSC_dma/usb_msc.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_types.h
BSP/USB_MSC_dma/usb_msc.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/tistdtypes.h
BSP/USB_MSC_dma/usb_msc.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_usb.h
BSP/USB_MSC_dma/usb_msc.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_general.h
BSP/USB_MSC_dma/usb_msc.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/soc.h
BSP/USB_MSC_dma/usb_msc.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_cpu.h
BSP/USB_MSC_dma/usb_msc.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_sysctrl.h
BSP/USB_MSC_dma/usb_msc.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_i2c.h
BSP/USB_MSC_dma/usb_msc.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_i2s.h
BSP/USB_MSC_dma/usb_msc.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_emif.h
BSP/USB_MSC_dma/usb_msc.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_uart.h
BSP/USB_MSC_dma/usb_msc.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_spi.h
BSP/USB_MSC_dma/usb_msc.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_mmcsd.h
BSP/USB_MSC_dma/usb_msc.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_lcdc.h
BSP/USB_MSC_dma/usb_msc.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_rtc.h
BSP/USB_MSC_dma/usb_msc.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_dma.h
BSP/USB_MSC_dma/usb_msc.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_sar.h
BSP/USB_MSC_dma/usb_msc.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_gpio.h
BSP/USB_MSC_dma/usb_msc.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_tim.h
BSP/USB_MSC_dma/usb_msc.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_wdt.h
BSP/USB_MSC_dma/usb_msc.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_idle.h
BSP/USB_MSC_dma/usb_msc.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_ldo.h
BSP/USB_MSC_dma/usb_msc.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_mcbsp.h
BSP/USB_MSC_dma/usb_msc.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_mcspi.h
BSP/USB_MSC_dma/usb_msc.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_uhpi.h
BSP/USB_MSC_dma/usb_msc.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_msc.h
BSP/USB_MSC_dma/usb_msc.obj: ../BSP/USB_MSC_dma/msc_media.h
BSP/USB_MSC_dma/usb_msc.obj: C:/ti/CCS_Project/c55_csl_3.08.01/ccs_v6.x_examples/drv/atafs/src/ata_.h
BSP/USB_MSC_dma/usb_msc.obj: C:/ti/CCS_Project/c55_csl_3.08.01/ccs_v6.x_examples/drv/atafs/src/ata.h
BSP/USB_MSC_dma/usb_msc.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_mmcsd_ataIf.h
BSP/USB_MSC_dma/usb_msc.obj: ../BSP/USB_MSC_dma/usb_descriptors.h
BSP/USB_MSC_dma/usb_msc.obj: C:/ti/CCS_Project/c55_csl_3.08.01/ccs_v6.x_examples/usb/LHP_V100_shiyan1/BSP/SD/sd_card.h
BSP/USB_MSC_dma/usb_msc.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_mmcsd.h
BSP/USB_MSC_dma/usb_msc.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_dma.h
BSP/USB_MSC_dma/usb_msc.obj: ../BSP/USB_MSC_dma/common.h
BSP/USB_MSC_dma/usb_msc.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/log.h
BSP/USB_MSC_dma/usb_msc.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/_log.h
BSP/USB_MSC_dma/usb_msc.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/std.h
BSP/USB_MSC_dma/usb_msc.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/trc.h
BSP/USB_MSC_dma/usb_msc.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/mbx.h
BSP/USB_MSC_dma/usb_msc.obj: F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stddef.h
BSP/USB_MSC_dma/usb_msc.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/que.h
BSP/USB_MSC_dma/usb_msc.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/fxn.h
BSP/USB_MSC_dma/usb_msc.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/mem.h
BSP/USB_MSC_dma/usb_msc.obj: F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stddef.h
BSP/USB_MSC_dma/usb_msc.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/sem.h
BSP/USB_MSC_dma/usb_msc.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/knl.h
BSP/USB_MSC_dma/usb_msc.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/atm.h
BSP/USB_MSC_dma/usb_msc.obj: F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stdarg.h
BSP/USB_MSC_dma/usb_msc.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/sts.h
BSP/USB_MSC_dma/usb_msc.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/swi.h
BSP/USB_MSC_dma/usb_msc.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/hwi.h
BSP/USB_MSC_dma/usb_msc.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/obj.h
BSP/USB_MSC_dma/usb_msc.obj: F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stddef.h
BSP/USB_MSC_dma/usb_msc.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/sys.h
BSP/USB_MSC_dma/usb_msc.obj: F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stdarg.h
BSP/USB_MSC_dma/usb_msc.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/tsk.h
BSP/USB_MSC_dma/usb_msc.obj: F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stdarg.h
BSP/USB_MSC_dma/usb_msc.obj: F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stddef.h
BSP/USB_MSC_dma/usb_msc.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/prd.h
BSP/USB_MSC_dma/usb_msc.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/trg.h
BSP/USB_MSC_dma/usb_msc.obj: F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stddef.h
BSP/USB_MSC_dma/usb_msc.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/_hook.h
BSP/USB_MSC_dma/usb_msc.obj: F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stdlib.h
BSP/USB_MSC_dma/usb_msc.obj: F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/linkage.h
BSP/USB_MSC_dma/usb_msc.obj: C:/ti_c55_lp/c55_dsplib_3.00/c55_dsplib_03.00.00.03/include/stdio.h
BSP/USB_MSC_dma/usb_msc.obj: F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/string.h
BSP/USB_MSC_dma/usb_msc.obj: C:/ti/CCS_Project/c55_csl_3.08.01/ccs_v6.x_examples/usb/LHP_V100_shiyan1/BSP/UART/uart.h
BSP/USB_MSC_dma/usb_msc.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_uart.h
BSP/USB_MSC_dma/usb_msc.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_intc.h
BSP/USB_MSC_dma/usb_msc.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_uartAux.h
BSP/USB_MSC_dma/usb_msc.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_sysctrl.h
BSP/USB_MSC_dma/usb_msc.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_pll.h
BSP/USB_MSC_dma/usb_msc.obj: F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stdarg.h
BSP/USB_MSC_dma/usb_msc.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_usbAux.h
BSP/USB_MSC_dma/usb_msc.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_mscAux.h

../BSP/USB_MSC_dma/usb_msc.c:

../BSP/USB_MSC_dma/usb_msc.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_usb.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_error.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_types.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/tistdtypes.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_usb.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_general.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/soc.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_cpu.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_sysctrl.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_i2c.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_i2s.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_emif.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_uart.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_spi.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_mmcsd.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_lcdc.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_rtc.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_dma.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_sar.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_gpio.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_tim.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_wdt.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_idle.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_ldo.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_mcbsp.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_mcspi.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_uhpi.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_msc.h:

../BSP/USB_MSC_dma/msc_media.h:

C:/ti/CCS_Project/c55_csl_3.08.01/ccs_v6.x_examples/drv/atafs/src/ata_.h:

C:/ti/CCS_Project/c55_csl_3.08.01/ccs_v6.x_examples/drv/atafs/src/ata.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_mmcsd_ataIf.h:

../BSP/USB_MSC_dma/usb_descriptors.h:

C:/ti/CCS_Project/c55_csl_3.08.01/ccs_v6.x_examples/usb/LHP_V100_shiyan1/BSP/SD/sd_card.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_mmcsd.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_dma.h:

../BSP/USB_MSC_dma/common.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/log.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/_log.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/std.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/trc.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/mbx.h:

F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stddef.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/que.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/fxn.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/mem.h:

F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stddef.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/sem.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/knl.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/atm.h:

F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stdarg.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/sts.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/swi.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/hwi.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/obj.h:

F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stddef.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/sys.h:

F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stdarg.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/tsk.h:

F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stdarg.h:

F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stddef.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/prd.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/trg.h:

F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stddef.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/_hook.h:

F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stdlib.h:

F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/linkage.h:

C:/ti_c55_lp/c55_dsplib_3.00/c55_dsplib_03.00.00.03/include/stdio.h:

F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/string.h:

C:/ti/CCS_Project/c55_csl_3.08.01/ccs_v6.x_examples/usb/LHP_V100_shiyan1/BSP/UART/uart.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_uart.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_intc.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_uartAux.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_sysctrl.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_pll.h:

F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stdarg.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_usbAux.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_mscAux.h:

