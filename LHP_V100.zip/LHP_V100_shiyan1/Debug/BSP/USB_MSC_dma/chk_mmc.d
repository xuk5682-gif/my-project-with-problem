# FIXED

BSP/USB_MSC_dma/chk_mmc.obj: ../BSP/USB_MSC_dma/chk_mmc.c
BSP/USB_MSC_dma/chk_mmc.obj: C:/ti/CCS_Project/c55_csl_3.08.01/ccs_v6.x_examples/drv/common/chk_mmc.h
BSP/USB_MSC_dma/chk_mmc.obj: C:/ti/CCS_Project/c55_csl_3.08.01/ccs_v6.x_examples/drv/atafs/src/ata.h
BSP/USB_MSC_dma/chk_mmc.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/tistdtypes.h
BSP/USB_MSC_dma/chk_mmc.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_mmcsd_ataIf.h
BSP/USB_MSC_dma/chk_mmc.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_types.h
BSP/USB_MSC_dma/chk_mmc.obj: C:/ti/CCS_Project/c55_csl_3.08.01/ccs_v6.x_examples/drv/atafs/src/ata_.h

../BSP/USB_MSC_dma/chk_mmc.c:

C:/ti/CCS_Project/c55_csl_3.08.01/ccs_v6.x_examples/drv/common/chk_mmc.h:

C:/ti/CCS_Project/c55_csl_3.08.01/ccs_v6.x_examples/drv/atafs/src/ata.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/tistdtypes.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_mmcsd_ataIf.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_types.h:

C:/ti/CCS_Project/c55_csl_3.08.01/ccs_v6.x_examples/drv/atafs/src/ata_.h:

