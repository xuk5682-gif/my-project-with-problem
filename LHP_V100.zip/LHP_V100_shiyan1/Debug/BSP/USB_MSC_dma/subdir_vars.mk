################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../BSP/USB_MSC_dma/chk_mmc.c \
../BSP/USB_MSC_dma/msc_media.c \
../BSP/USB_MSC_dma/usb_descriptors.c \
../BSP/USB_MSC_dma/usb_msc.c 

C_DEPS += \
./BSP/USB_MSC_dma/chk_mmc.d \
./BSP/USB_MSC_dma/msc_media.d \
./BSP/USB_MSC_dma/usb_descriptors.d \
./BSP/USB_MSC_dma/usb_msc.d 

OBJS += \
./BSP/USB_MSC_dma/chk_mmc.obj \
./BSP/USB_MSC_dma/msc_media.obj \
./BSP/USB_MSC_dma/usb_descriptors.obj \
./BSP/USB_MSC_dma/usb_msc.obj 

OBJS__QUOTED += \
"BSP\USB_MSC_dma\chk_mmc.obj" \
"BSP\USB_MSC_dma\msc_media.obj" \
"BSP\USB_MSC_dma\usb_descriptors.obj" \
"BSP\USB_MSC_dma\usb_msc.obj" 

C_DEPS__QUOTED += \
"BSP\USB_MSC_dma\chk_mmc.d" \
"BSP\USB_MSC_dma\msc_media.d" \
"BSP\USB_MSC_dma\usb_descriptors.d" \
"BSP\USB_MSC_dma\usb_msc.d" 

C_SRCS__QUOTED += \
"../BSP/USB_MSC_dma/chk_mmc.c" \
"../BSP/USB_MSC_dma/msc_media.c" \
"../BSP/USB_MSC_dma/usb_descriptors.c" \
"../BSP/USB_MSC_dma/usb_msc.c" 


