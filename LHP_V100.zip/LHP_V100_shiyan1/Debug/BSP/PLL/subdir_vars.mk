################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../BSP/PLL/PLL_SetSysClk.c 

C_DEPS += \
./BSP/PLL/PLL_SetSysClk.d 

OBJS += \
./BSP/PLL/PLL_SetSysClk.obj 

OBJS__QUOTED += \
"BSP\PLL\PLL_SetSysClk.obj" 

C_DEPS__QUOTED += \
"BSP\PLL\PLL_SetSysClk.d" 

C_SRCS__QUOTED += \
"../BSP/PLL/PLL_SetSysClk.c" 


