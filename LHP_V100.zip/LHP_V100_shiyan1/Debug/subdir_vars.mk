################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
S??_SRCS += \
./VC5505_CSL_BIOS_cfg.s?? 

TCF_SRCS += \
../VC5505_CSL_BIOS_cfg.tcf 

C_SRCS += \
./VC5505_CSL_BIOS_cfg_c.c 

S??_DEPS += \
./VC5505_CSL_BIOS_cfg.d 

GEN_CMDS += \
./VC5505_CSL_BIOS_cfg.cmd 

GEN_FILES += \
./VC5505_CSL_BIOS_cfg.cmd \
./VC5505_CSL_BIOS_cfg.s?? \
./VC5505_CSL_BIOS_cfg_c.c 

C_DEPS += \
./VC5505_CSL_BIOS_cfg_c.d 

OBJS += \
./VC5505_CSL_BIOS_cfg.obj \
./VC5505_CSL_BIOS_cfg_c.obj 

GEN_MISC_FILES += \
./VC5505_CSL_BIOS_cfg.h \
./VC5505_CSL_BIOS_cfg.h?? \
./VC5505_CSL_BIOS_.cdb 

S??_DEPS__QUOTED += \
"VC5505_CSL_BIOS_cfg.d" 

OBJS__QUOTED += \
"VC5505_CSL_BIOS_cfg.obj" \
"VC5505_CSL_BIOS_cfg_c.obj" 

GEN_MISC_FILES__QUOTED += \
"VC5505_CSL_BIOS_cfg.h" \
"VC5505_CSL_BIOS_cfg.h??" \
"VC5505_CSL_BIOS_.cdb" 

C_DEPS__QUOTED += \
"VC5505_CSL_BIOS_cfg_c.d" 

GEN_FILES__QUOTED += \
"VC5505_CSL_BIOS_cfg.cmd" \
"VC5505_CSL_BIOS_cfg.s??" \
"VC5505_CSL_BIOS_cfg_c.c" 

S??_SRCS__QUOTED += \
"./VC5505_CSL_BIOS_cfg.s??" 

S??_OBJS__QUOTED += \
"VC5505_CSL_BIOS_cfg.obj" 

C_SRCS__QUOTED += \
"./VC5505_CSL_BIOS_cfg_c.c" 


