# FIXED

USER/main.obj: ../USER/main.c
USER/main.obj: C:/ti/CCS_Project/c55_csl_3.08.01/ccs_v6.x_examples/usb/LHP_V100_shiyan1/BSP/USB_MSC_dma/common.h
USER/main.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/log.h
USER/main.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/_log.h
USER/main.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/std.h
USER/main.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/tistdtypes.h
USER/main.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/trc.h
USER/main.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/mbx.h
USER/main.obj: F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stddef.h
USER/main.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/que.h
USER/main.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/fxn.h
USER/main.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/mem.h
USER/main.obj: F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stddef.h
USER/main.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/sem.h
USER/main.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/knl.h
USER/main.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/atm.h
USER/main.obj: F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stdarg.h
USER/main.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/sts.h
USER/main.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/swi.h
USER/main.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/hwi.h
USER/main.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/obj.h
USER/main.obj: F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stddef.h
USER/main.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/sys.h
USER/main.obj: F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stdarg.h
USER/main.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/tsk.h
USER/main.obj: F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stdarg.h
USER/main.obj: F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stddef.h
USER/main.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/prd.h
USER/main.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/trg.h
USER/main.obj: F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stddef.h
USER/main.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/_hook.h
USER/main.obj: F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stdlib.h
USER/main.obj: F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/linkage.h
USER/main.obj: C:/ti_c55_lp/c55_dsplib_3.00/c55_dsplib_03.00.00.03/include/stdio.h
USER/main.obj: F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/string.h
USER/main.obj: C:/ti/CCS_Project/c55_csl_3.08.01/ccs_v6.x_examples/usb/LHP_V100_shiyan1/BSP/UART/uart.h
USER/main.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_uart.h
USER/main.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr.h
USER/main.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_error.h
USER/main.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_types.h
USER/main.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_uart.h
USER/main.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_general.h
USER/main.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/soc.h
USER/main.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_cpu.h
USER/main.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_sysctrl.h
USER/main.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_i2c.h
USER/main.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_i2s.h
USER/main.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_emif.h
USER/main.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_spi.h
USER/main.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_mmcsd.h
USER/main.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_lcdc.h
USER/main.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_rtc.h
USER/main.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_dma.h
USER/main.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_sar.h
USER/main.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_usb.h
USER/main.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_gpio.h
USER/main.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_tim.h
USER/main.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_wdt.h
USER/main.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_idle.h
USER/main.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_ldo.h
USER/main.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_mcbsp.h
USER/main.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_mcspi.h
USER/main.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_uhpi.h
USER/main.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_intc.h
USER/main.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_uartAux.h
USER/main.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_sysctrl.h
USER/main.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_pll.h
USER/main.obj: F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stdarg.h
USER/main.obj: C:/ti/CCS_Project/c55_csl_3.08.01/ccs_v6.x_examples/usb/LHP_V100_shiyan1/BSP/PLL/PLL_SetSysClk.h
USER/main.obj: C:/ti/CCS_Project/c55_csl_3.08.01/ccs_v6.x_examples/usb/LHP_V100_shiyan1/BSP/SD/sd_card.h
USER/main.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_mmcsd.h
USER/main.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_dma.h
USER/main.obj: C:/ti/CCS_Project/c55_csl_3.08.01/ccs_v6.x_examples/usb/LHP_V100_shiyan1/BSP/USB_MSC_dma/msc_media.h
USER/main.obj: C:/ti/CCS_Project/c55_csl_3.08.01/ccs_v6.x_examples/drv/atafs/src/ata_.h
USER/main.obj: C:/ti/CCS_Project/c55_csl_3.08.01/ccs_v6.x_examples/drv/atafs/src/ata.h
USER/main.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_msc.h
USER/main.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_usb.h
USER/main.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_mmcsd_ataIf.h
USER/main.obj: C:/ti/CCS_Project/c55_csl_3.08.01/ccs_v6.x_examples/usb/LHP_V100_shiyan1/BSP/USB_MSC_dma/usb_msc.h
USER/main.obj: C:/ti/CCS_Project/c55_csl_3.08.01/ccs_v6.x_examples/usb/LHP_V100_shiyan1/BSP/USB_MSC_dma/usb_descriptors.h
USER/main.obj: C:/ti/CCS_Project/c55_csl_3.08.01/ccs_v6.x_examples/usb/LHP_V100_shiyan1/BSP/UART/uart.h
USER/main.obj: F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stdarg.h
USER/main.obj: C:/ti/CCS_Project/c55_csl_3.08.01/ccs_v6.x_examples/usb/LHP_V100_shiyan1/TASK/SD/sd_task.h
USER/main.obj: ../USER/init_interrupts.h
USER/main.obj: C:/ti/CCS_Project/c55_csl_3.08.01/inc/evm5515.h
USER/main.obj: ../USER/gel_evm5515.h

../USER/main.c:

C:/ti/CCS_Project/c55_csl_3.08.01/ccs_v6.x_examples/usb/LHP_V100_shiyan1/BSP/USB_MSC_dma/common.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/log.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/_log.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/std.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/tistdtypes.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/trc.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/mbx.h:

F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stddef.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/que.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/fxn.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/mem.h:

F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stddef.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/sem.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/knl.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/atm.h:

F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stdarg.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/sts.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/swi.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/hwi.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/obj.h:

F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stddef.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/sys.h:

F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stdarg.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/tsk.h:

F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stdarg.h:

F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stddef.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/prd.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/trg.h:

F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stddef.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/_hook.h:

F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stdlib.h:

F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/linkage.h:

C:/ti_c55_lp/c55_dsplib_3.00/c55_dsplib_03.00.00.03/include/stdio.h:

F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/string.h:

C:/ti/CCS_Project/c55_csl_3.08.01/ccs_v6.x_examples/usb/LHP_V100_shiyan1/BSP/UART/uart.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_uart.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_error.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_types.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_uart.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_general.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/soc.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_cpu.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_sysctrl.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_i2c.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_i2s.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_emif.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_spi.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_mmcsd.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_lcdc.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_rtc.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_dma.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_sar.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_usb.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_gpio.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_tim.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_wdt.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_idle.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_ldo.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_mcbsp.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_mcspi.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/cslr_uhpi.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_intc.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_uartAux.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_sysctrl.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_pll.h:

F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stdarg.h:

C:/ti/CCS_Project/c55_csl_3.08.01/ccs_v6.x_examples/usb/LHP_V100_shiyan1/BSP/PLL/PLL_SetSysClk.h:

C:/ti/CCS_Project/c55_csl_3.08.01/ccs_v6.x_examples/usb/LHP_V100_shiyan1/BSP/SD/sd_card.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_mmcsd.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_dma.h:

C:/ti/CCS_Project/c55_csl_3.08.01/ccs_v6.x_examples/usb/LHP_V100_shiyan1/BSP/USB_MSC_dma/msc_media.h:

C:/ti/CCS_Project/c55_csl_3.08.01/ccs_v6.x_examples/drv/atafs/src/ata_.h:

C:/ti/CCS_Project/c55_csl_3.08.01/ccs_v6.x_examples/drv/atafs/src/ata.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_msc.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_usb.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/csl_mmcsd_ataIf.h:

C:/ti/CCS_Project/c55_csl_3.08.01/ccs_v6.x_examples/usb/LHP_V100_shiyan1/BSP/USB_MSC_dma/usb_msc.h:

C:/ti/CCS_Project/c55_csl_3.08.01/ccs_v6.x_examples/usb/LHP_V100_shiyan1/BSP/USB_MSC_dma/usb_descriptors.h:

C:/ti/CCS_Project/c55_csl_3.08.01/ccs_v6.x_examples/usb/LHP_V100_shiyan1/BSP/UART/uart.h:

F:/ti/ccs1281/ccs/tools/compiler/c5500_4.4.1/include/stdarg.h:

C:/ti/CCS_Project/c55_csl_3.08.01/ccs_v6.x_examples/usb/LHP_V100_shiyan1/TASK/SD/sd_task.h:

../USER/init_interrupts.h:

C:/ti/CCS_Project/c55_csl_3.08.01/inc/evm5515.h:

../USER/gel_evm5515.h:

