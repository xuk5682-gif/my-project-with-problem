# FIXED

USER/gel_evm5515.obj: ../USER/gel_evm5515.c
USER/gel_evm5515.obj: ../USER/gel_evm5515.h
USER/gel_evm5515.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/tistdtypes.h

../USER/gel_evm5515.c:

../USER/gel_evm5515.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/tistdtypes.h:

