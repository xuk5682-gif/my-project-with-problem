################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../USER/gel_evm5515.c \
../USER/init_interrupts.c \
../USER/main.c 

C_DEPS += \
./USER/gel_evm5515.d \
./USER/init_interrupts.d \
./USER/main.d 

OBJS += \
./USER/gel_evm5515.obj \
./USER/init_interrupts.obj \
./USER/main.obj 

OBJS__QUOTED += \
"USER\gel_evm5515.obj" \
"USER\init_interrupts.obj" \
"USER\main.obj" 

C_DEPS__QUOTED += \
"USER\gel_evm5515.d" \
"USER\init_interrupts.d" \
"USER\main.d" 

C_SRCS__QUOTED += \
"../USER/gel_evm5515.c" \
"../USER/init_interrupts.c" \
"../USER/main.c" 


