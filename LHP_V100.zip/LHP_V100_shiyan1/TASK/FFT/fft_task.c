/*
 * FFT 任务
 * - 等待 AD 任务分发的块消息
 * - 对缓冲区做频谱分析，阈值判断
 *   - 大于阈值：LMS 降噪后再次频谱分析
 *   - 小于阈值：直接输出
 * - 将结果存入内部 buffer 后通过回调/占位通知串口线程
 */
#include <std.h>
#include <sem.h>
#include <tsk.h>
#include <mem.h>
#include <string.h>
#include <stdio.h>
#include "fft_task.h"
#include "../BSP/ADS127L11/ads127l11.h"
/* 简单环形队列，存放指向 SPI DMA 乒乓缓冲的只读视图 */
typedef struct {
	ADS_Block q[16];      //队列缓冲区，存储 16 个数据块描述符  buf（数据指针）、length（长度）、which（Ping/Pong 标识）
    volatile Uns write_idx;   //写索引（Write Index） volatile 表示可能被中断修改
    volatile Uns read_idx;    //读索引（Read Index）
    SEM_Obj semItemsObj;  //用于同步，表示队列中有数据可读
    SEM_Handle semItems;  //用于信号量操作
} FFT_Queue;

static FFT_Queue s_fftQueue;
static TSK_Handle s_fftTask;

static volatile Bool s_fftStopRequested = FALSE;

/* 可配置阈值 */
static float s_threshold = 0.5f;

/* 占位：频谱分析与 LMS，按项目替换为实际实现 */
static Void do_fft_analyze(const Uint16 *samples, Uint16 length, float *outSpectrum, Uint16 outLen)
{
    /* 占位实现：将样本简单归一映射到 outSpectrum */
    Uint16 i;
    Uint16 n = (length < outLen) ? length : outLen;
    for (i = 0; i < n; ++i) {
        outSpectrum[i] = (float)(samples[i] & 0xFFFFu) / 65535.0f;
    }
    for (i = n; i < outLen; ++i) {
        outSpectrum[i] = 0.0f;
    }
}
static Void do_lms_denoise(const Uint16 *in, Uint16 length, Uint16 *out)
{
    /* 占位实现：直接拷贝 */
    memcpy(out, in, (size_t)length * sizeof(Uint16));
}

/* 将分析结果通知串口线程（占位：请在工程中替换为实际接口） */
Void UART_notifySpectrum(const float *spectrum, Uint16 length)
{
    (void)spectrum; (void)length;
    /* 占位：仅打印 */
    //SEM_post(s_uartQueue.semItems);
    // printf("UART_notifySpectrum called, len=%u\n", length);
}

static inline Uns fft_queue_count(const FFT_Queue *q)
{
    return (q->write_idx - q->read_idx) & (sizeof(q->q)/sizeof(q->q[0]) - 1u);
}
static Void fft_queue_push(const ADS_Block *b)
{
    FFT_Queue *q = &s_fftQueue;
    Uns next = (q->write_idx + 1u) & (sizeof(q->q)/sizeof(q->q[0]) - 1u);
    if (next == q->read_idx) {
        /* 覆盖最旧 */
        q->read_idx = (q->read_idx + 1u) & (sizeof(q->q)/sizeof(q->q[0]) - 1u);
    }
    q->q[q->write_idx] = *b;
    q->write_idx = next;
    SEM_ipost(q->semItems);
}
static Bool fft_queue_pop(ADS_Block *out)
{
    FFT_Queue *q = &s_fftQueue;
    if (q->read_idx == q->write_idx) return FALSE;
    *out = q->q[q->read_idx];
    q->read_idx = (q->read_idx + 1u) & (sizeof(q->q)/sizeof(q->q[0]) - 1u);
    return TRUE;
}

static Void FFT_Task_main(Arg arg0)
{
    (void)arg0;
    const Uint16 spectrumLen = 256; /* 可按需求调整 */
    float spectrumBuf[256];
    Uint16 denoiseBuf[ADS_INT_BUF_ELEMS]; /* 与 block 长度一致 */

    for (;;) {
        /* 等待有块 */
        SEM_pend(s_fftQueue.semItems, SYS_FOREVER);
        /* 退出请求检查 */
		if (s_fftStopRequested) {
		  /* clear handle and exit */
			s_fftTask = NULL;
			return;
		}

        /* 尽量批量处理 */
		ADS_Block blk;
        while (fft_queue_pop(&blk)) {
            /* 第一次频谱 */
            do_fft_analyze(blk.buf, blk.length, spectrumBuf, spectrumLen);

            /* 简单阈值判定：以最大值为例 */
            float maxVal = 0.0f;
            Uint16 i = 0;
            for (i = 0; i < spectrumLen; ++i) {
                if (spectrumBuf[i] > maxVal) maxVal = spectrumBuf[i];
            }

            if (maxVal > s_threshold) {
                /* 有目标：先 LMS，再 FFT */
                do_lms_denoise(blk.buf, blk.length, denoiseBuf);
                do_fft_analyze(denoiseBuf, blk.length, spectrumBuf, spectrumLen);
                UART_notifySpectrum(spectrumBuf, spectrumLen);
            } else {
                /* 无目标：直接上报频谱 */
                UART_notifySpectrum(spectrumBuf, spectrumLen);
            }
        }
    }
}

Void FFT_Task_init(Void)
{
    memset(&s_fftQueue, 0, sizeof(s_fftQueue));
    s_fftQueue.semItems = &s_fftQueue.semItemsObj;
    SEM_new(s_fftQueue.semItems, 0);

    TSK_Attrs attrs = TSK_ATTRS; // 对于旧版 DSP/BIOS 可能是 TSK_Attrs attrs = TSK_ATTRS;
    attrs.priority = 1;          // 低优先级
    attrs.stacksize = 8192;      // 足够大
    s_fftTask = TSK_create(FFT_Task_main, &attrs, NULL);
    if (s_fftTask == NULL) {
        printf("FFT_Task_create failed\n");
    }
}

Void FFT_Task_enqueue(const ADS_Block *blk)
{
    fft_queue_push(blk);
}

Void FFT_Task_setThreshold(float threshold)
{
    s_threshold = threshold;
}

/* Request FFT task to stop and wait for exit */
Void FFT_Task_stop(Void)
{
    if (s_fftTask == NULL) return;
    s_fftStopRequested = TRUE;
    /* wake the task if it's waiting */
    if (s_fftQueue.semItems) SEM_post(s_fftQueue.semItems);
    /* wait for task to clear handle */
    {
        int wait = 1000;
        while (s_fftTask != NULL && wait-- > 0) {
            TSK_sleep(1);
        }
        if (s_fftTask != NULL) {
            printf("FFT_Task_stop: task did not exit in time\n");
        }
    }
    s_fftStopRequested = FALSE;
}

/* Restart FFT task: stop if running, then init */
Void FFT_Task_restart(Void)
{
    FFT_Task_stop();
    FFT_Task_init();
}

//#include <std.h>
//#include <tsk.h>
//#include <sem.h>
//#include <sys.h>
//
//#include <stdlib.h>
//#include <math.h>
//#include <tms320.h>
//#include <stdio.h>
//#include <dsplib.h>
//
//#include "spi_dma.h"
///* ===== 锟脚猴拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟� ===== */
////static Semaphore_Struct   gFftSemStruct;
//extern SEM_Handle   gFftSem = NULL;
//
////static Task_Struct        gFftTaskStruct;
//static Char               gFftTaskStack[1024];   /* 锟斤拷要锟缴碉拷锟斤拷 */
//

//void bit_reverse(int16_t *real, int16_t *imag, int N) {
//    int i, j, k;
//    int16_t temp_real, temp_imag;
//
//    for (i = 1; i < N; i++) {  // i 锟斤拷 1 锟斤拷始锟斤拷锟斤拷 N-1
//        j = 0;
//        // 锟斤拷锟斤拷 i 锟斤拷位锟斤拷转锟斤拷锟斤拷 j
//        for (k = 0; k < log2(N); k++) {  // 锟斤拷要锟斤拷锟斤拷 log2(N) 锟轿ｏ拷锟斤拷锟斤拷 N 锟侥讹拷锟斤拷锟狡筹拷锟斤拷
//            if (i & (1 << (log2(N) - k - 1))) {  // 锟叫断碉拷 k 位锟角凤拷为 1
//                j |= (1 << k);  // 锟斤拷锟斤拷锟�1锟斤拷锟酵斤拷锟斤拷转锟斤拷锟斤拷锟侥碉拷 k 位锟斤拷为 1
//            }
//        }
//
//        // 锟斤拷锟斤拷原锟斤拷锟捷碉拷顺锟斤拷只锟斤拷锟斤拷锟斤拷 i 锟斤拷 j 之锟斤拷锟轿伙拷锟�
//        if (i < j) {
//            // Swap real parts
//            temp_real = real[i];  // 锟饺憋拷锟斤拷 real[i] 锟斤拷值
//            real[i] = real[j];    // 锟斤拷 real[j] 锟斤拷值锟斤拷 real[i]
//            real[j] = temp_real;  // 锟斤拷锟斤拷锟斤拷锟� real[i] 锟斤拷值锟斤拷 real[j]
//
//            // Swap imaginary parts
//            temp_imag = imag[i];  // 同锟斤拷锟侥斤拷锟斤拷锟介部
//            imag[i] = imag[j];
//            imag[j] = temp_imag;
//        }
//    }
//}
//
//
//
//// 蝶形运算
//void fft_butterfly(float *re, float *im, int N, int step) {
//    int half = step / 2;
//    float angle = -2.0 * M_PI / step;
//
//    for (int k = 0; k < N; k += step) {  // 按块遍历
//        for (int j = 0; j < half; ++j) {  // 计算每个块内的蝶形运算
//            int p = k + j;
//            int q = p + half;
//
//            // 计算旋转因子 W
//            float wr = cos(angle * j);
//            float wi = sin(angle * j);
//
//            // 蝶形合并
//            float tr = wr * re[q] - wi * im[q];  // 计算实部
//            float ti = wr * im[q] + wi * re[q];  // 计算虚部
//
//            // 更新值
//            re[q] = re[p] - tr;
//            im[q] = im[p] - ti;
//            re[p] = re[p] + tr;
//            im[p] = im[p] + ti;
//        }
//    }
//}
//
//void fft(float *re, float *im, int N) {
//    bit_reverse_permute(re, im, N);     // DIT 先位反转
//    for (int step = 2; step <= N; step <<= 1) {
//        butterfly_layer(re, im, N, step);
//        // 若做定点/防溢出，可在此做分层缩放（block floating）
//    }
//}



//void fft(int16_t *real, int16_t *imag, int N) {
//    int stage, i, j, k, m;
//    int numButterflies, numPoints, fftSize;
//    int16_t wr, wi, temp_real, temp_imag;
//    int16_t tr, ti;
//
//    // 锟斤拷锟斤拷每锟斤拷锟阶讹拷
//    for (stage = 1; stage <= log2(N); stage++) {
//        numButterflies = N / (1 << stage);  // 每一锟阶讹拷锟斤拷要锟斤拷锟斤拷锟侥猴拷锟斤拷锟斤拷
//        numPoints = 1 << stage;  // 每一锟阶讹拷每锟斤拷小 FFT 锟斤拷要锟侥碉拷锟斤拷
//        fftSize = numPoints / 2;  // 每锟轿碉拷锟轿诧拷锟斤拷锟斤拷要锟斤拷锟斤拷锟侥碉拷锟斤拷
//
//        // 锟斤拷锟斤拷每锟斤拷锟阶段的达拷锟斤拷锟斤拷锟斤拷
//        for (i = 0; i < N; i += numPoints) {
//            for (j = 0; j < fftSize; j++) {
//                // Twiddle factor 锟斤拷锟姐（锟斤拷转锟斤拷锟接ｏ拷
//                wr = cos(2 * M_PI * j / numPoints);  // Twiddle factor 锟斤拷实锟斤拷
//                wi = -sin(2 * M_PI * j / numPoints);  // Twiddle factor 锟斤拷锟介部
//
//                // 锟斤拷锟轿硷拷锟斤拷
//                k = i + j + fftSize;  // 锟斤拷锟斤拷猿锟轿伙拷锟�
//                tr = wr * real[k] - wi * imag[k];  // Twiddle factor 锟斤拷锟皆革拷锟斤拷
//                ti = wi * real[k] + wr * imag[k];  // Twiddle factor 锟斤拷锟皆革拷锟斤拷
//
//                // 锟斤拷锟斤拷值锟斤拷锟街憋拷锟斤拷锟绞碉拷锟斤拷锟斤拷椴�
//                real[k] = real[i + j] - tr;  // 锟皆称碉拷母锟斤拷锟�
//                imag[k] = imag[i + j] - ti;
//                real[i + j] = real[i + j] + tr;  // 原锟斤拷母锟斤拷锟�
//                imag[i + j] = imag[i + j] + ti;
//            }
//        }
//    }
//}
//for (int i = 0; i < N; i++) {
//    int16_t magnitude = sqrt(real_part[i] * real_part[i] + imag_part[i] * imag_part[i]);
//    // 锟斤拷锟狡碉拷追锟斤拷锟�
//    printf("Frequency bin %d: %d\n", i, magnitude);
//}




