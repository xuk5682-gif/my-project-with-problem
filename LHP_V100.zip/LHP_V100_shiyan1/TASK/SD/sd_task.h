#ifndef SD_TASK_H
#define SD_TASK_H

#include <csl_types.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Create and start the SD task that performs AppMediaInit and file write */
void SD_Task_init(void);

/* Request SD task to stop; wakes task and it will exit loop and terminate */
void SD_Task_stop(void);

/* Restart SD task: stop if running, then re-init and start */
void SD_Task_restart(void);


#ifdef __cplusplus
}
#endif

#endif /* SD_TASK_H */


