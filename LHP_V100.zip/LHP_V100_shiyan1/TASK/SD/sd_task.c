#include "sd_task.h"
#include "common.h"
#include "msc_media.h"
#include "sd_card.h"
#include "uart.h"
#include "ata.h"
//#include <tsk.h>
#include <sem.h>
#include <stdio.h>
#include <string.h>

#include <errno.h>
#include "../BSP/ADS127L11/ads127l11.h"

static size_t local_strnlen(const char *s, size_t maxlen)
{
	size_t n = 0;
	if (!s) return 0;
	while (n < maxlen && s[n]) ++n;
	return n;
}
/* SD card data buffering */
#define SD_BUFFER_SIZE_WORDS (512)  /* Uint16 words 8kb * 1024/2 = 4096 */
static Uint16 sd_data_buffer[SD_BUFFER_SIZE_WORDS];
static volatile Uint32 sd_buffer_index = 0;
static volatile Uint32 sd_file_counter = 1;
static SEM_Handle sdTaskSem = NULL;

/* Static write buffers for CSV output (avoid stack/DMA aliasing) */
static unsigned char sd_csv_bytebuf[512];
static AtaUint16 sd_csv_writeSectorBuf[256];


static volatile Bool sdTaskStopRequested = FALSE;
 TSK_Handle sdTaskHandle = NULL;
 /* Indicator that the SD task has fully exited and released resources */
 static volatile Bool sd_stopped = FALSE;


static Void SD_FileTask(Arg arg0)
{
	(void)arg0;
	extern CSL_MmcsdHandle mmcsdHandle;
	{
		/* Initialize SD card */
		extern AtaMMCState *gpstrMMCState;
		extern AtaState ATALogicalUnit[];
		extern AtaUint16 _AtaBuffer[];

		memset(&ATALogicalUnit[0], 0, sizeof(ATALogicalUnit[0]));
		/* ensure media state points to MMC state */
		gpstrMMCState->hMmcSd = mmcsdHandle;
		ATALogicalUnit[0].pAtaMediaState = gpstrMMCState;
        MMC_initState(&ATALogicalUnit[0]);
		ATALogicalUnit[0]._AtaWriteBuffer = _AtaBuffer;

		if (AppMediaInit(0) == CSL_MSC_MEDIACCESS_SUCCESS) {
        /* Initialization complete, now enter main loop for data processing */
        CSL_USB_DEBUG_PRINT("SD_FileTask: Initialization complete, entering data processing loop\r\n");
		int i ;
		for(i = 0; i < SD_BUFFER_SIZE_WORDS; i++)
		{
			sd_data_buffer[i] = i;
		}
//    				for (i = 0; i < SD_BUFFER_SIZE_WORDS; i++) {
//    				    sd_data_buffer[i] = (sd_data_buffer[i] >> 8) | (sd_data_buffer[i] << 8);
//    				}
			while (1) {

				/* Wait for buffer full signal or stop/resume requests.
				 * SD_Task_stop() sets sdTaskStopRequested and posts the semaphore
				 * so the task will wake and can exit cleanly.
				 */
				if (sdTaskStopRequested) {
					CSL_USB_DEBUG_PRINT("SD_FileTask: stop requested at loop start, exiting\r\n");
					break;
				}
				/* Normal wait: pend until buffer full (producer posts) or stop requested */
				/* Use SYS_FOREVER and rely on external wake-up via SEM_post */
				CSL_USB_DEBUG_PRINT("SD_FileTask: about to pend on semaphore with SYS_FOREVER\r\n");
				if (sdTaskSem) {
					CSL_USB_DEBUG_PRINT("SD_FileTask: calling SEM_pend with SYS_FOREVER\r\n");
					SEM_pend(sdTaskSem, SYS_FOREVER);
					CSL_USB_DEBUG_PRINT("SD_FileTask: SEM_pend(SYS_FOREVER) returned! stopRequested=%d\r\n", (int)sdTaskStopRequested);
					CSL_USB_DEBUG_PRINT("SD_FileTask: woke up from semaphore, checking stop flag\r\n");
				} else {
					CSL_USB_DEBUG_PRINT("SD_FileTask: no semaphore available, cannot wait\r\n");
				}
				if (sdTaskStopRequested) {
					CSL_USB_DEBUG_PRINT("SD_FileTask: stop requested after wait loop, exiting\r\n");
					break;
				}
				if (sdTaskStopRequested) break;



//				/* Wait for buffer full signal */
//				SEM_pend(sdTaskSem, SYS_FOREVER);

				/* Buffer is full, create data file */
				char filename[13];  /* "DATA_999.TXT" + null terminator */
				sprintf(filename, "DATA_%03lu.csv", (unsigned long)sd_file_counter);

				AtaFile dataFile;
				memset(&dataFile, 0, sizeof(dataFile)); //�����ʼ����ȷ���ṹ�������ֶ�Ϊ0
				dataFile.pDrive = &ATALogicalUnit[0];  //��������ָ��SD���߼���Ԫ0

				/* Check for stop request before starting file operations */
				if (sdTaskStopRequested) break;

				/* Initialize file and go to root directory */
				AtaError aerr = ATA_fileInit(dataFile.pDrive, &dataFile); //�ļ���ʼ���������ļ�������Ĭ�ϲ���
				if (aerr != ATA_ERROR_NONE) {
					CSL_USB_DEBUG_PRINT("SD_FileTask: ATA_fileInit failed %d\r\n", (int)aerr);
					continue;
				}
				if (sdTaskStopRequested) break;
				aerr = ATA_cdRoot(&dataFile);//�л���Ŀ¼����λ��FAT�ļ�ϵͳ�ĸ�Ŀ¼
				if (aerr != ATA_ERROR_NONE) {
					CSL_USB_DEBUG_PRINT("SD_FileTask: ATA_cdRoot failed %d\r\n", (int)aerr);
					continue;
				}
				if (sdTaskStopRequested) break;
				/* Set filename and create file  ��ȡ���ļ�������չ��*/
				char name[9], ext[4];
				/* Parse filename: extract name and extension */
				const char *dot_pos = strchr(filename, '.'); //����ʹ�� strchr ���������ļ����е�һ�����ֵĵ㣨.����λ�ã�������λ�õ�ָ�븳�� dot_pos��
				if (dot_pos) {
					size_t name_len = dot_pos - filename;//8-0=0 ��ȡ�ļ�������
					if (name_len > 8) name_len = 8;
					memcpy(name, filename, name_len);
					name[name_len] = '\0';                // name = "DATA_001"
					size_t ext_len = strlen(dot_pos + 1); //��ȡ��չ������ txt = 3
					if (ext_len > 3) ext_len = 3;
					memcpy(ext, dot_pos + 1, ext_len);
					ext[ext_len] = '\0';                  // ext = "txt"
				} else {
					/* No extension, use whole as name */
					size_t name_len = strlen(filename);
					if (name_len > 8) name_len = 8;
					memcpy(name, filename, name_len);
					name[name_len] = '\0';
					ext[0] = '\0';
				}

				aerr = ATA_setFileName(&dataFile, name, ext);  //�������ƣ�����������name��ext���õ�AtaFile�ṹ��
				if (aerr != ATA_ERROR_NONE) {
					CSL_USB_DEBUG_PRINT("SD_FileTask: ATA_setFileName(%s) failed %d\r\n", filename, (int)aerr);
					continue;
				}
				if (sdTaskStopRequested) break;
				aerr = ATA_create(&dataFile);//�����ļ���
				if (aerr != ATA_ERROR_NONE) {
					CSL_USB_DEBUG_PRINT("SD_FileTask: ATA_create(%s) failed %d\r\n", filename, (int)aerr);
					continue;
				}
				if (sdTaskStopRequested) break;


//				/* Write buffer data to file */
//				/* Convert buffer to 16-bit words (high byte first for ASCII) */
//				aerr = ATA_write(&dataFile, sd_data_buffer, SD_BUFFER_SIZE_WORDS);
//				if (aerr != ATA_ERROR_NONE) {
//					CSL_USB_DEBUG_PRINT("SD_FileTask: ATA_write failed, error %d\n",  (int)aerr);
//					break;
//				}

				{
					/* Build full 256-word sectors from ASCII lines to avoid writing out-of-bounds memory.
					 * We'll pack characters high-byte-first into AtaUint16 words and write full sectors.
					 */
					extern AtaUint16 _AtaBuffer[]; /* aligned DMA-safe buffer from msc_media.c */
					AtaUint16 *sectorBuf = _AtaBuffer;
					char lineBuf[64];
					int sectorWordPos = 0; /* number of words filled in sectorBuf (words) */
					int i, j;
					int lineLen;

					/* Each sample line (no header)
					 * Strategy: build a 512-byte byteBuf filled with ASCII lines (CRLF),
					 * then pack little-endian into AtaUint16 words into the DMA buffer _AtaBuffer
					 * and call ATA_write on full 256-word sectors.
					 */
					{
						unsigned char *byteBuf = sd_csv_bytebuf;
						AtaUint16 *writeSectorBuf = sd_csv_writeSectorBuf;
						int bytePos = 0;

						/* clear buffers to avoid residual data causing line concatenation */
						memset(byteBuf, 0, 512);
						memset(writeSectorBuf, 0, 256 * sizeof(AtaUint16));

						for (i = 0; i < SD_BUFFER_SIZE_WORDS; ++i) {
							/* ensure no residual data in the line buffer */
							memset(lineBuf, 0, sizeof(lineBuf));
							{
								unsigned val = (unsigned)sd_data_buffer[i];
								int pos = 0;
								/* temporary buffer for digits in reverse order */
								char rev[16];
								int rpos = 0;

								if (val == 0) {
									rev[rpos++] = '0';
								} else {
									while (val != 0 && rpos < (int)sizeof(rev)) {
										rev[rpos++] = (char)('0' + (val % 10));
										val /= 10;
									}
								}
								/* copy reversed digits into lineBuf in correct order */
								while (rpos > 0 && pos < (int)sizeof(lineBuf) - 3) {
									lineBuf[pos++] = rev[--rpos];
								}
								/* Append CR LF if space permits */
								if (pos < (int)sizeof(lineBuf) - 1) lineBuf[pos++] = '\r';
								if (pos < (int)sizeof(lineBuf) - 1) lineBuf[pos++] = '\n';
								/* Null-terminate safely */
								if (pos < (int)sizeof(lineBuf)) lineBuf[pos] = '\0';
								else lineBuf[sizeof(lineBuf) - 1] = '\0';
								lineLen = pos;
							}
//							/* append bytes to byteBuf */
							/* snprintf returns the number of characters that would have been written
							 * (excluding the terminating NUL). If the output was truncated, the
							 * returned value may be >= sizeof(lineBuf). Clamp to the actual number
							 * of bytes present in lineBuf to avoid reading past the buffer.
							 */
							if (lineLen < 0) {
								lineLen = 0;
							} else if (lineLen >= (int)sizeof(lineBuf)) {
								/* truncated: actual bytes stored in buffer are sizeof(lineBuf)-1 */
								lineLen = (int)sizeof(lineBuf) - 1;
							}
							/* Use actual stored length to avoid reading beyond the NUL terminator */

								int actual = (int)local_strnlen(lineBuf, sizeof(lineBuf));
								for (j = 0; j < actual; ++j) {
								if (bytePos < (int)sizeof(byteBuf)) {
									byteBuf[bytePos++] = (unsigned char)lineBuf[j];
								}
								/* if buffer full, pack & write */
								if (bytePos == (int)sizeof(byteBuf)) {
									int w;
									/* pack little-endian: word = (high<<8) | low where high=byte[2*k+1], low=byte[2*k] */
									for (w = 0; w < 256; ++w) {
										int bidx = w * 2;
										unsigned char low = byteBuf[bidx];
										unsigned char high = byteBuf[bidx + 1];
										writeSectorBuf[w] = (AtaUint16)((low << 8) | high);
									}
									/* diagnostic preview */
									{

										unsigned int hwiKey = HWI_disable();
										AtaError wa = ATA_write(&dataFile, writeSectorBuf, 256);
										/* clear local write buffer after write */
										memset(writeSectorBuf, 0, sizeof(writeSectorBuf));
										HWI_restore(hwiKey);
										bytePos = 0;
										if (wa != ATA_ERROR_NONE) {
											aerr = wa;
											CSL_USB_DEBUG_PRINT("SD_FileTask: ATA_write (CSV sector) failed, error %d\r\n", (int)aerr);
											break;
										}
									}

								}
							}
							if (sdTaskStopRequested) break;
							if (aerr != ATA_ERROR_NONE) break;
						}
						/* flush remaining partial sector if any */
						if (aerr == ATA_ERROR_NONE && bytePos > 0) {
							int pad;
							for (pad = bytePos; pad < 512; ++pad) byteBuf[pad] = 0;
							int w;
							for (w = 0; w < 256; ++w) {
								int bidx = w * 2;
								unsigned char low = byteBuf[bidx];
								unsigned char high = byteBuf[bidx + 1];
								writeSectorBuf[w] = (AtaUint16)((low << 8) | high);
							}
							{
									unsigned int hwiKey = HWI_disable();
									AtaError wa = ATA_write(&dataFile, writeSectorBuf, 256);
									memset(writeSectorBuf, 0, sizeof(writeSectorBuf));
									HWI_restore(hwiKey);
								if (wa != ATA_ERROR_NONE) {
									aerr = wa;
									CSL_USB_DEBUG_PRINT("SD_FileTask: ATA_write (CSV final sector) failed, error %d\r\n", (int)aerr);
								}
						    }
						}
					}
				}

				if (sdTaskStopRequested) break;
				if (aerr == ATA_ERROR_NONE) {
					if (sdTaskStopRequested) break;
					/* Read back first physical sector of the file for diagnosis (non-destructive) */
					{
						AtaUint16 tmpRead[256];
						AtaUint16 offsetInSector = 0;
						AtaSector phySector = _AtaCalculatePhySectorAndOffsetFromCluster(&dataFile, &offsetInSector);
						AtaError rerr = _AtaReadSector(phySector, dataFile.pDrive, tmpRead, 0);
						if (rerr != ATA_ERROR_NONE) {
							CSL_USB_DEBUG_PRINT("SD_FileTask: _AtaReadSector readback failed %d\r\n", (int)rerr);
						}
					}
					/* Close file and flush */
					aerr = ATA_close(&dataFile);
					//CSL_USB_DEBUG_PRINT("SD_FileTask: ATA_close(%s) -> %d\n", filename, (int)aerr);
					if (sdTaskStopRequested) break;
					AtaError ferr = MMC_flushFat(ATALogicalUnit[0].pAtaMediaState);
					CSL_USB_DEBUG_PRINT("SD_FileTask: MMC_flushFat after %s -> %d, file #%lu saved\r\n",
									   filename, (int)ferr, (unsigned long)sd_file_counter);
					sd_file_counter++;
				}
				if (sdTaskStopRequested) break;
				/* Reset buffer for next data collection */
				sd_buffer_index = 0;
			}
	    }
	}
	/* mark task handle cleared so SD_Task_stop can detect exit */
	    CSL_USB_DEBUG_PRINT("SD_FileTask: setting stopped flag and clearing handle\r\n");
	    sd_stopped = TRUE;
		sdTaskHandle = NULL;
}

/* Enqueue AD data block for SD card storage */
//������8kb��������ݴ洢     ��ƹ�һ��������ݷ���һ��8kb ������ SD_BUFFER_SIZE_WORDS ��������һ���������
void SD_Task_enqueue(const ADS_Block *blk)
{
    if (!blk || !blk->buf || blk->length == 0) {
        return;
    }

    /* Copy data to buffer */
    Uint32 copy_words = blk->length;  //һ����������С1kb = 512uint16
    //(����Ҫ��֤��index����4096֮��֪ͨsd���߳�ִ�к����֮���¸�copywords����) �洢ʱ��С�ڲɼ�ʱ��
    if (sd_buffer_index + copy_words > SD_BUFFER_SIZE_WORDS) {  //4096+512>4096
        copy_words = SD_BUFFER_SIZE_WORDS - sd_buffer_index;    //0
    }

    if (copy_words > 0) {
        memcpy(&sd_data_buffer[sd_buffer_index], blk->buf, copy_words * sizeof(Uint16));
        sd_buffer_index += copy_words;
    }

    /* Check if buffer is full */
    if (sd_buffer_index >= SD_BUFFER_SIZE_WORDS) {
        /* Buffer full, trigger file write by posting semaphore to SD task */
        if (sdTaskSem) {
            SEM_post(sdTaskSem);
        }
    }
}

Void SD_Task_init(Void)
{
	/* Create semaphore for SD data buffer signaling */
		sdTaskSem = SEM_create(0, NULL);
		if (sdTaskSem == NULL) {
			CSL_USB_DEBUG_PRINT("SEM_create sdTaskSem failed\r\n");
			return;
		}
	/* create a low-priority task to run AppMediaInit and write file */
	{
		TSK_Attrs attrs = TSK_ATTRS;
		attrs.priority = 6;
		attrs.stacksize = 4096;
		sd_stopped = FALSE;
			sdTaskStopRequested = FALSE;
			if ((sdTaskHandle = TSK_create((Fxn)SD_FileTask, &attrs, NULL)) == NULL) {
				CSL_USB_DEBUG_PRINT("TSK_create SD_FileTask failed\r\n");
				sdTaskHandle = NULL;
				sd_stopped = TRUE; /* treat as stopped on failure */
		    }
	}
}



/* Request SD task to stop; wakes task and it will exit loop and terminate */
void SD_Task_stop(void)
{
//    sdTaskStopRequested = TRUE;
//    if (sdTaskSem) SEM_post(sdTaskSem);
      /* flush FAT to ensure filesystem metadata is committed */
	   //printf("SD_Task_stop: FUNCTION CALLED\n");
	   CSL_USB_DEBUG_PRINT("SD_Task_stop: starting stop sequence\r\n");

      if (ATALogicalUnit[0].pAtaMediaState) {
          MMC_flushFat(ATALogicalUnit[0].pAtaMediaState);
          MMC_reset(ATALogicalUnit[0].pAtaMediaState);
      }
      //printf("SD_Task_stop: about to set stop flag and post semaphore\n");
      CSL_USB_DEBUG_PRINT("SD_Task_stop: setting stop flag and posting semaphore\r\n");
      /* request task stop and wake it if blocked */
      sdTaskStopRequested = TRUE;
      if (sdTaskSem) {
			//printf("SD_Task_stop: calling SEM_post\n");
			SEM_post(sdTaskSem);
			//printf("SD_Task_stop: SEM_post completed\n");
		} else {
			//printf("SD_Task_stop: warning - no semaphore available\n");
			CSL_USB_DEBUG_PRINT("SD_Task_stop: warning - no semaphore available\r\n");
		}

      /* wait for SD task to signal stopped (timeout to avoid infinite block) */
//           {
//               int timeout_ticks = 100000; /* Shorter timeout since UART has higher priority */
//               CSL_USB_DEBUG_PRINT("SD_Task_stop: waiting for task to stop with timeout\r\n");
//               while (!sd_stopped && timeout_ticks-- > 0) {
//                   /* Busy wait - allow other tasks to run via scheduler */
//                   /* With UART at higher priority, we need to be more aggressive */
//                   if (timeout_ticks % 1000 == 0) {  /* Every 1000 iterations */
//                       /* Yield CPU to allow lower priority tasks to run */
//                       /* In DSP/BIOS, this helps with priority scheduling */
//                   }
//               }
//               if (!sd_stopped) {
//                   CSL_USB_DEBUG_PRINT("SD_Task_stop: task did not exit in time, forcing cleanup\r\n");
//                   /* Force cleanup - task handle will be invalid after this */
//                   sdTaskHandle = NULL;
//                   sd_stopped = TRUE; /* Mark as stopped to prevent further issues */
//                   CSL_USB_DEBUG_PRINT("SD_Task_stop: cleanup completed\r\n");
//               } else {
//                   CSL_USB_DEBUG_PRINT("SD_Task_stop: confirmed stopped\r\n");
//               }
//           }
}


/* Restart SD task: stop if running, then re-init and start */
void SD_Task_restart(void)
{
    /* stop SD task and ensure clean state */
    SD_Task_stop();

    /* clear flags */
    sdTaskStopRequested = FALSE;
    sd_stopped = FALSE;
    /* delete semaphore if exists to avoid leaking on re-create */
    if (sdTaskSem) {
        SEM_delete(sdTaskSem);
        sdTaskSem = NULL;
    }

    /* Re-initialize MMC/ATA state if needed */
    if (ATALogicalUnit[0].pAtaMediaState) {
        MMC_reset(ATALogicalUnit[0].pAtaMediaState);
    }

    /* start SD task again */
    SD_Task_init();
}




///* Try create a test file via ATA API: BOARD.TXT */
//	{ /* Ensure there is space: check free bytes and delete NEWFILE.TXT if low */
//		AtaError diskErr;
//		AtaUint32 freeBytes = ATA_diskFree(ATALogicalUnit[0].pAtaMediaState, &diskErr);//���̿ռ��������
//		//CSL_USB_DEBUG_PRINT("SD_FileTask: Disk free space before BOARD = %lu bytes, diskErr=%d\n", (unsigned long)freeBytes, (int)diskErr);
//		if (freeBytes < 512u) {
//			CSL_USB_DEBUG_PRINT("SD_FileTask: low space, attempting to delete NEWFILE.TXT to free space\n");
////						AtaFile delF;
////						memset(&delF,0,sizeof(delF));
////						delF.pDrive = &ATALogicalUnit[0];
////						if (ATA_setFileName(&delF, "NEWFILE", "TXT") == ATA_ERROR_NONE) {
////							AtaError derr = ATA_delete(&delF);
////							CSL_USB_DEBUG_PRINT("SD_FileTask: ATA_delete(NEWFILE.TXT) -> %d\n", (int)derr);
////							freeBytes = ATA_diskFree(ATALogicalUnit[0].pAtaMediaState, &diskErr);
////							CSL_USB_DEBUG_PRINT("SD_FileTask: Disk free space after delete = %lu bytes, diskErr=%d\n", (unsigned long)freeBytes, (int)diskErr);
////						}
//		}
//		AtaFile af;  //�ļ��ṹ��ʼ��
//		memset(&af, 0, sizeof(af));
//		af.pDrive = &ATALogicalUnit[0];
//		AtaError aerr = ATA_fileInit(af.pDrive, &af); //��ʼ���ļ��ṹ�壬���ø����ֶε�Ĭ��ֵ
//		 if (aerr != ATA_ERROR_NONE) {
//			 CSL_USB_DEBUG_PRINT("SD_FileTask: ATA_fileInit failed %d\n", (int)aerr);
//		 } else {
//			 aerr = ATA_cdRoot(&af);  //�л�����Ŀ¼��FAT�ļ�ϵͳ�еĸ�Ŀ¼��
//			 //CSL_USB_DEBUG_PRINT("SD_FileTask: ATA_cdRoot -> %d\n", (int)aerr);
//			 if (aerr == ATA_ERROR_NONE) {
//				 aerr = ATA_setFileName(&af, "BOARD1", "TXT"); //�����ļ�������չ����BOARD.TXT��
//	          }
//		 }
//
//		if (aerr != ATA_ERROR_NONE) {
//			CSL_USB_DEBUG_PRINT("SD_FileTask: ATA_setFileName(BOARD) failed %d\n", (int)aerr);
//		} else {
//			aerr = ATA_create(&af);  //��FAT���з���أ�Ϊ�ļ�����Ŀ¼��  ������FAT����Ŀ¼����
//			if (aerr != ATA_ERROR_NONE) {
//				CSL_USB_DEBUG_PRINT("SD_FileTask: ATA_create(BOARD) failed %d\n", (int)aerr);
//			} else {
//				/* prepare one sector of data (ASCII), pack high byte first */
//				static AtaUint16 writeWords[256];
//				const char *msg = "Board created by device. This is a test.\r\n";
//				size_t msglen = strlen(msg);
//				size_t wi = 0;
//				size_t bi = 0;
//				for (wi = 0; wi < 256; ++wi) {
//					unsigned char c1 = 0, c2 = 0;
//					if (bi < msglen) c1 = (unsigned char)msg[bi++];
//					if (bi < msglen) c2 = (unsigned char)msg[bi++];
//					writeWords[wi] = (AtaUint16)((c1 << 8) | c2);
//				}
//				aerr = ATA_write(&af, writeWords, 256);
//				if (aerr != ATA_ERROR_NONE) {
//					CSL_USB_DEBUG_PRINT("SD_FileTask: ATA_write(BOARD) failed %d\n", (int)aerr);
//				} else {
//					//CSL_USB_DEBUG_PRINT("SD_FileTask: ATA_write(BOARD) success\n");
//					aerr = ATA_close(&af);
//					//CSL_USB_DEBUG_PRINT("SD_FileTask: ATA_close(BOARD) -> %d\n", (int)aerr);
//					/* flush FAT to commit directory */
//					AtaError ferr = MMC_flushFat(ATALogicalUnit[0].pAtaMediaState);
//					//CSL_USB_DEBUG_PRINT("SD_FileTask: MMC_flushFat after BOARD -> %d\n", (int)ferr);
//				}
//			}
//		}
//	}
//} else {
//		CSL_USB_DEBUG_PRINT("SD_FileTask AppMediaInit failed\n");
//}


