/* ============================================================================
 * Copyright (c) 2008-2016 Texas Instruments Incorporated.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/


/** @file csl_uart_intc_example.c
 *
 *  @brief UART example to test the Interrupt mode functionality of CSL UART
 *
 *
 * \page    page18  CSL UART EXAMPLE DOCUMENTATION
 *
 * \section UART3   UART EXAMPLE3 - INTERRUPT MODE TEST
 *
 * \subsection UART3x    TEST DESCRIPTION:
 *      This test is to verify the CSL UART module operation in interrupt mode.
 * This test code communicates with the HyperTerminal on the host PC through
 * UART module on C5535 DSP operating in interrupt mode. UART peripheral is
 * configured by the test code to the following values.
 * Baud Rate - 2400.
 * Data bits - 8.
 * Parity - None.
 * Stop bits - 1.
 * Flow control - None.
 * HyperTerminal on the host PC should be configured with the same values to
 * to proper communication with the C5535/C5515/C5517 EVM. C5535/C5515/C5517 EVM should be
 * connected to the host PC using an RS232 cable and HyperTerminal on the host
 * PC should be opened and connected.This test works at all the PLL frequencies.
 *
 * This test code reads characters entered by the user on the HypeTerminal
 * continuously one character at a time. For each character entered on the
 * HyperTerminal, URAT generates a receive interrupt and the character is
 * read in the Rx ISR. Symbol '$' needs to be entered on the HyperTerminal to
 * terminate the test.
 * Upon running the test, details of the test will be displayed on the
 * HyperTerminal. A message will be displayed prompting to enter a character.
 * Character entered on the HyperTerminal will be read by the test code and
 * and echoed back to the HyperTerminal until the symbol '$' is entered on the
 * HyperTerminal. Messages displayed to direct the user will be transmitted to
 * the HyperTerminal using Polled mode.
 *
 * @verbatim
   Messages displayed on the HyperTerminal during this test will be as shown
   below.

      ====================================================================
      ==                                                                ==
      ==  UART INTERRUPT TEST!                                          ==
      ==  TEST READS A CHARACTER FROM HYPERTERMINAL CONTINUOUSLY        ==
      ==  ENTER '$' TO END THE TEST                                     ==
      ==                                                                ==
      ==  Enter char:C                                                  ==
      ==  C                                                             ==
      ==  Enter char:S                                                  ==
      ==  S                                                             ==
      ==  Enter char:L                                                  ==
      ==  L                                                             ==
      ==  Enter char:$                                                  ==
      ==  $                                                             ==
      ==                                                                ==
      ==  YOU HAVE ENTERED '$'.                                         ==
      ==  END OF THE TEST!!                                             ==
      ==                                                                ==
      ====================================================================

  @endverbatim
 *
 * Manual inspection is required to verify the success of each step.
 *
 * NOTE: THIS TEST HAS BEEN DEVELOPED TO WORK WITH CHIP VERSIONS C5535, C5515
 * AND C5517. MAKE SURE THAT PROPER CHIP VERSION MACRO IS DEFINED IN THE FILE
 * c55xx_csl\inc\csl_general.h.
 *
 * \subsection UART3y    TEST PROCEDURE:
 *  @li Connect the RS232 cable; One end to the UART port on the C5535/C5515/C5517 EVM(J13/J1/J2)
 *      and other  to the COM port of the Windows Xp PC.
 *  @li Open the HyperTerminal on the Host PC. To open the HyperTerminal click
 *      on 'Start->Programs->Accessories->Communications->HyperTerminal
 *  @li Disconnect the HyperTerminal by selecting menu Call->Disconnect
 *  @li Select Menu 'File->Properties' and click on the Button 'Configure'
 *     \n  Set 'Bits Per Second(Baud Rate)' to 2400.
 *     \n  Set 'Data bits' to 8.
 *     \n  Set 'Parity' to None.
 *     \n  Set 'Stop bits' to 1.
 *     \n  Set 'Flow control' to None.
 *     \n  Click on 'OK' button.
 *     \n  HyperTerminal is configured and ready for communication
 *  @li Connect the HyperTerminal by selecting menu Call->Call.
 *  @li Open the CCS and connect the target (C5535/C5515/C5517 EVM)
 *  @li Open the project "CSL_UART_IntExample.pjt" and build it
 *  @li Load the program on to the target
 *  @li Set the PLL frequency to 12.288MHz
 *  @li Run the program and observe the test result
 *  @li Repeat the test at the following PLL frequencies
 *      C5515: 60MHz and 100MHz
 *      C5517: 60MHz, 100MHz, 150MHz and 200MHz
 *      C5535 eZdsp: 60MHz and 100MHz
 *  @li Repeat the test in Release mode
 *
 * \subsection UART3z    TEST RESULT:
 *  @li All the CSL APIs should return success
 *  @li Characters entered on the HyperTerminal should be read and echoed back
 *      to the HyperTerminal properly.
 *  @li Data sent by the UART should be displayed on the HyperTerminal properly
 *
 */

/* ============================================================================
 * Revision History
 * ================
 * 05-Sept-2008 Created
 * 23-Jul-2012 Added C5517 Compatibility
 * 10-Mar-2016 Updates to header
 * ============================================================================
 */

#include <stdio.h>
#include "csl_uart.h"
#include "csl_uartAux.h"
#include "csl_intc.h"
#include "csl_general.h"
#include "csl_sysctrl.h"
#include "csl_pll.h"
#include <stdarg.h>
#define CSL_TEST_FAILED         (1U)
#define CSL_TEST_PASSED         (0)
#define CSL_UART_BUF_LEN        (4U)

/* Global constants */
/* String length to be received and transmitted */
#define WR_STR_LEN        80
#define RD_STR_LEN        10

#define CSL_PLL_DIV_000    (0)
#define CSL_PLL_DIV_001    (1u)
#define CSL_PLL_DIV_002    (2u)
#define CSL_PLL_DIV_003    (3u)
#define CSL_PLL_DIV_004    (4u)
#define CSL_PLL_DIV_005    (5u)
#define CSL_PLL_DIV_006    (6u)
#define CSL_PLL_DIV_007    (7u)

#define CSL_PLL_CLOCKIN    (32768u)

#define PLL_CNTL1        *(ioport volatile unsigned *)0x1C20
#define PLL_CNTL2        *(ioport volatile unsigned *)0x1C21
#define PLL_CNTL3        *(ioport volatile unsigned *)0x1C22
#define PLL_CNTL4        *(ioport volatile unsigned *)0x1C23


/* ���/������ⲿ�þ�������ֻ�� uart.c �þͱ�ŵ����� */
extern CSL_UartObj    uartObj;
extern CSL_UartHandle hUart;
/* UART printf function declaration for debug output redirection */
int uart_printf(const char *format, ...);

/* ����Ҫ���ļ�����������������ɾ�������� uart.c �� static */
//extern char   buffer1[30];
//extern char   buffer2[10];
//extern char   buffer3[30];
//extern Uint16 gcount, mutex;
//extern char  *ptr;
//extern volatile Bool endOfTest;
//
/* ��������ڣ��������ļ��ṩ�� */
extern void VECSTART(void);

/**
 *  \brief  Interrupt Service Routine to handle UART Line Status Interrupt
 *
 *  \param  none
 *
 *  \return none
 */
void uart_lsiIsr(void);

/**
 *  \brief  Interrupt Service Routine to handle UART Character Timeout Interrupt
 *
 *  \param  none
 *
 *  \return none
 */
void uart_ctoIsr(void);


/**
 *  \brief  Interrupt Service Routine to handle UART Transmit Interrupt
 *
 *  \param  none
 *
 *  \return none
 */
void uart_txIsr(void);


/**
 *  \brief  Interrupt Service Routine to handle UART Receive Interrupt
 *
 *  \param  none
 *
 *  \return none
 */
void uart_rxIsr(void);

/**
 *  \brief  Interrupt Dispatcher to identify interrupt source
 *
 *  This function identify the type of UART interrupt generated and
 *  calls concerned ISR to handle the interrupt
 *
 *  \param  none
 *
 *  \return none
 */
interrupt void UART_intrDispatch(void);


/**
 *  \brief  UART interrupt Test function
 *
 *   This function verifies the UART operation in interrupt mode.
 *   This function runs in an infinite loop to read the characters
 *   from HyperTerminal and echo the characters back to HyperTerminal.
 *
 *  \param  none
 *
 *  \return Test result(Only Failure Case)
 */
CSL_Status uart_Int_Init(void);






