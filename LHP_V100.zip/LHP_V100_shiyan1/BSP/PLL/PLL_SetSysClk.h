#include "csl_pll.h"
#include "csl_general.h"
#include "csl_sysctrl.h"

/**
 *  \brief    Function to calculate the memory clock rate
 *
 * This function computes the memory clock rate value depending on the
 * CPU frequency. This value is used as clock divider value for
 * calling the API MMC_sendOpCond(). Value of the clock rate computed
 * by this function will change depending on the system clock value
 * and MMC maximum clock value passed as parameter to this function.
 * Minimum clock rate value returned by this function is 0 and
 * maximum clock rate value returned by this function is 255.
 * Clock derived using the clock rate returned by this API will be
 * the nearest value to 'memMaxClk'.
 *
 *  \param    memMaxClk  - Maximum memory clock rate
 *
 *  \return   MMC clock rate value
 */
 CSL_Status PLL_setSysClk_102MHz_From12MHz(void);

 void Clkout_enable(void);
 void delay_cycles(unsigned long cycles);
 void delay_ms(unsigned int ms);
