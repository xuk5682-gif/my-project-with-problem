#include "PLL_SetSysClk.h"

/**
 *  \brief    Function to calculate the memory clock rate
 *
 * This function computes the memory clock rate value depending on the
 * CPU frequency. This value is used as clock divider value for
 * calling the API MMC_sendOpCond(). Value of the clock rate computed
 * by this function will change depending on the system clock value
 * and MMC maximum clock value passed as parameter to this function.
 * Minimum clock rate value returned by this function is 0 and
 * maximum clock rate value returned by this function is 255.
 * Clock derived using the clock rate returned by this API will be
 * the nearest value to 'memMaxClk'.
 *
 *  \param    memMaxClk  - Maximum memory clock rate
 *
 *  \return   MMC clock rate value
 */
//-----------------------------------------------------------------------------------------------
/* 依据 12 MHz 外部晶振，把 SYSCLK 配到 60 MHz
   * 模式2 ： 设置RDBYPASS=0 且 OUTDIVEN=1：
     SYSCLK=CLKREF×(M+4)/[(RDRATIO+4)×(ODRATIO+1)]
     SYSCLK=12×(16+4)​/[(0+4)×(0+1)]=240/4=60 MHz
     SYSCLK=12×(30+4)​/[(0+4)×(0+1)]=408/4=102 MHz
     SYSCLK=12×(96+4)​/[(0+4)×(2+1)]=1200/12=100 MHz
    * 模式4 ： 设置RDBYPASS=1 且 OUTDIVEN=1：
    *  SYSCLK=CLKREF×(M+4)/(ODRATIO+1)
     SYSCLK=12×(21+4)​/(2+1)=300/3=100 MHz​
  */
CSL_Status PLL_setSysClk_102MHz_From12MHz(void)  //
{
      CSL_Status  status;
      PLL_Obj     pllObj;
      PLL_Handle  hPll;
      PLL_Config  cfg;

      /* 1) 初始化并获取句柄 */
      status = PLL_init(&pllObj, CSL_PLL_INST_0);
      if (status != CSL_SOK) return status;
      hPll = &pllObj;

      /* 2) 进入旁路 + 复位（安全改参） */
      (void)PLL_bypass(hPll);
      (void)PLL_reset(hPll);


      cfg.PLLINCNTL  = CSL_FMK(SYS_CGCR2_RDRATIO, 0)             /* ÷4 */
                     | CSL_FMK(SYS_CGCR2_RDBYPASS, 0);           /* 不旁路参考分频 */

      cfg.PLLCNTL1   = CSL_FMK(SYS_CGCR1_M, 16)                  /* 倍频系数 M=96 */
                     | CSL_FMK(SYS_CGCR1_PLL_PWRDN, 0)           /* 上电 */
                     | CSL_FMK(SYS_CGCR1_RSVD, CSL_SYS_CGCR1_RSVD_CLEAR);

      cfg.PLLOUTCNTL = CSL_FMK(SYS_CGCR4_ODRATIO, 0)             /* ÷3 */
                     | CSL_FMK(SYS_CGCR4_OUTDIVEN, 1);           /* 使能输出分频 */

      cfg.PLLCNTL2   = CSL_SYS_CGCR3_RESETVAL;                   /* 按 TI 推荐：0x0806 */

      /* 4) 下发配置、启动、等待锁定 */
      status = PLL_config(hPll, &cfg);
      if (status != CSL_SOK) return status;

      status = PLL_enable(hPll);      /* 退出复位、启动 VCO   CCR2 = 1 */
      if (status != CSL_SOK) return status;

      /* 简单等待上锁（可换成读状态位） */
      volatile Uint32 i; for (i = 0; i < 200000u; ++i) { __asm(" NOP"); }



      return CSL_SOK;
}

void Clkout_enable(void)
{
     volatile CSL_CpuRegs * cpu = (volatile CSL_CpuRegs *)CSL_CPU_REGS;

       Uint16 st3_55 = 0;
       st3_55 |= (CSL_CPU_ST3_55_CLKOFF_ENABLE  << CSL_CPU_ST3_55_CLKOFF_SHIFT);   // CL=3 (100MHz)
       cpu->ST3_55 = st3_55;
}

void delay_cycles(unsigned long cycles)
{
    volatile unsigned long i;
    for (i = 0; i < cycles; i++) {
        __asm("    nop");   // 空指令，避免被优化
    }
}
void delay_ms(unsigned int ms)
{
    while(ms--)
    {
        delay_cycles(100000);   // 1 ms @ 100 MHz
    }
}

