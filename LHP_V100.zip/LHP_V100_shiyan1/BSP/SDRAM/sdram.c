
#include <stdio.h>
#include <string.h>
#include <csl_types.h>
#include <csl_dma.h>
#include <csl_emif.h>
#include <csl_general.h>

#include "sdram.h"
#include "cslr_emif.h"
#include "csl_pll.h"



#ifdef CSL_SDRAM_USE_ALIGNED_BUFFER
#pragma DATA_ALIGN(gSdramWriteBuffer,32); /*32-byte boundary and it works*/
#endif
Uint16 gSdramWriteBuffer[CSL_SDRAM_TEST_BUFFER_WORD_COUNT];

#ifdef CSL_SDRAM_USE_ALIGNED_BUFFER
#pragma DATA_ALIGN(gSdramReadBuffer,32); /*32-byte boundary and it works*/
#endif
Uint16 gSdramReadBuffer[CSL_SDRAM_TEST_BUFFER_WORD_COUNT];

 volatile Uint32    gSdramCSnBASE;
 Uint32             gSdramDMABYTEADDR;
 CSL_DMATxBurstLen  burstLen;

 static CSL_DMA_Handle        dmaWrHandle;
 static CSL_DMA_Handle        dmaRdHandle;
 static CSL_DMA_Config        dmaConfig;
 static CSL_DMA_ChannelObj    dmaWrChanObj;
 static CSL_DMA_ChannelObj    dmaRdChanObj;



 CSL_Status emif_sdram_init(void)
 {
     CSL_Status             status;
     Uint16             i, j;
     Uint32             startWordOffset;
     Uint16             numOfWords;

     status                 = CSL_SOK;
     startWordOffset        = CSL_SDRAM_TEST_START_OFFSET;
     numOfWords         = CSL_SDRAM_TEST_BUFFER_WORD_COUNT;
     gSdramCSnBASE      = CSL_SDRAM_DATA_WORD_ADDR;
     gSdramDMABYTEADDR  = CSL_SDRAM_DMA3_BYTE_ADDR;
     burstLen           = CSL_DMA_TXBURST_1WORD;

     /* Initialize Dma */
     status = DMA_init();
     if (status != CSL_SOK)
     {
         printf("DMA_init Failed!\n");
     }

     memset(&gSdramWriteBuffer, 0x0, sizeof(gSdramWriteBuffer));


     status = CSL_setupSDRAM();
     if(CSL_SOK != status)
     {
         printf("SDRAM SETUP: Bad Status\n");

     }


//         /*Dma write*/
//         status = CSL_sdramConfDmaWriteChan((startWordOffset+(j*numOfWords)), numOfWords);
//         if(CSL_SOK != status)
//         {
//             printf("SDRAM DMA WRITE CHAN CONF: Bad Status\n");
//         }
//
//         /*Start Dma write*/
//         status = DMA_start(dmaWrHandle);
//         if(status != CSL_SOK)
//         {
//             printf("DMA WRITE START Failed!!\n");
//             return status;
//         }
//
//         /* Check transfer complete status*/
//         while(DMA_getStatus(dmaWrHandle));
//
//         status = DMA_close(dmaWrHandle);
//         if(status != CSL_SOK)
//         {
//             printf("SRAM DMA close Failed!!\n");
//             return status;
//         }



//         /*Dma read*/
//         status = CSL_sdramConfDmaReadChan((startWordOffset+(j*numOfWords)), numOfWords);
//         if(CSL_SOK != status)
//         {
//             printf("SDRAM DMA READ CHAN CONF: Bad Status\n");
//         }
//
//         /* Start Dma read */
//         status = DMA_start(dmaRdHandle);
//         if(status != CSL_SOK)
//         {
//             printf("DMA READ START Failed!!\n");
//             return(status);
//         }
//
//         /* Check transfer complete status */
//         while(DMA_getStatus(dmaRdHandle));
//
//         status = DMA_close(dmaRdHandle);
//         if(status != CSL_SOK)
//         {
//             printf("SRAM DMA close Failed!!\n");
//             return status;
//         }
//
//         printf("DMA Data Read of %d-words from SDRAM @%lx Complete\n", numOfWords,
//                 (gSdramCSnBASE+startWordOffset+(j*numOfWords)));




     return status;
 }


 CSL_Status CSL_sdramConfDmaWriteChan(Uint32 dDestWordOffset, Uint16 numOfWords)
 {
     CSL_Status status;

     status = CSL_SOK;

     /*Configure DMA channel for nor write*/
     dmaConfig.pingPongMode = CSL_DMA_PING_PONG_DISABLE;
     dmaConfig.autoMode     = CSL_DMA_AUTORELOAD_DISABLE;
     dmaConfig.burstLen     = burstLen;
     dmaConfig.trigger      = CSL_DMA_SOFTWARE_TRIGGER;
     dmaConfig.dmaEvt       = CSL_DMA_EVT_NONE;
     dmaConfig.dmaInt       = CSL_DMA_INTERRUPT_DISABLE;
     dmaConfig.chanDir      = CSL_DMA_WRITE;
     dmaConfig.trfType      = CSL_DMA_TRANSFER_MEMORY;
     /*Data length in bytes*/
     dmaConfig.dataLen      = numOfWords*2;
     dmaConfig.srcAddr      = (Uint32)&gSdramWriteBuffer[0];
     /*DMA address of CS0 + offset byte address*/
     dmaConfig.destAddr     = gSdramDMABYTEADDR+(dDestWordOffset*2);



     dmaWrHandle = DMA_open(CSL_SDRAM_DMA_CHAN, &dmaWrChanObj, &status);
     if(dmaWrHandle == NULL)
     {
         printf("DMA_open of Chan%d-Write Failed!\n", CSL_SDRAM_DMA_CHAN);
         return -1;
     }

     /* Configure a Dma channel */
     status = DMA_config(dmaWrHandle, &dmaConfig);
     if(status != CSL_SOK)
     {
         printf("DMA_config of Chan%d-Write Failed!\n", CSL_SDRAM_DMA_CHAN);
         return -1;
     }

     return status;
 }

 CSL_Status CSL_sdramConfDmaReadChan(Uint32 dSrcWordOffset, Uint16 numOfWords)
 {
     CSL_Status status;

     status = CSL_SOK;

     /* Configure DMA channel  for nor read */
     dmaConfig.pingPongMode = CSL_DMA_PING_PONG_DISABLE;
     dmaConfig.autoMode     = CSL_DMA_AUTORELOAD_DISABLE;
     dmaConfig.burstLen     = burstLen;
     dmaConfig.trigger      = CSL_DMA_SOFTWARE_TRIGGER;
     dmaConfig.dmaEvt       = CSL_DMA_EVT_NONE;
     dmaConfig.dmaInt       = CSL_DMA_INTERRUPT_DISABLE;
     dmaConfig.chanDir      = CSL_DMA_READ;
     dmaConfig.trfType      = CSL_DMA_TRANSFER_MEMORY;
     /*Data length in bytes*/
     dmaConfig.dataLen      = numOfWords*2;
     /*DMA address of CS2 + offset byte address*/
     dmaConfig.srcAddr      = gSdramDMABYTEADDR+(dSrcWordOffset*2);
     dmaConfig.destAddr     = (Uint32)&gSdramReadBuffer[0];

     dmaRdHandle = DMA_open(CSL_SDRAM_DMA_CHAN, &dmaRdChanObj, &status);
     if(dmaRdHandle == NULL)
     {
         printf("DMA_open of Chan%d-Read Failed!\n", CSL_SDRAM_DMA_CHAN);
         return -1;
     }

     /* Configure a Dma channel */
     status = DMA_config(dmaRdHandle, &dmaConfig);
     if(status != CSL_SOK)
     {
         printf("DMA_config of Chan%d-Read Failed!\n", CSL_SDRAM_DMA_CHAN);
         return -1;
     }

     return status;
 }



static CSL_Status CSL_setupSDRAM(void)
 {
     CSL_SdramCfg            sdramCfg;
     CSL_SdramTimr           sdramTimr;
     CSL_EmifHandle          hEmif;
     CSL_SdramRowSize        rowSize;
     CSL_EmifObj             emifObj;
     CSL_Status              status;
     CSL_Status              result;
     Uint16                  i;
     Uint16                  looper;


     hEmif   = &emifObj;
     rowSize = CSL_SDRAM_ROW_ADDR_BITS_12;

     /* Initialize Emif module */
     status = EMIF_init(&emifObj);
     if(status != CSL_SOK)
     {
        printf("EMIF SDRAM Init Failed!!\n");
        return(result);
     }

     /* Assign values to sdram config structure */
     sdramCfg.NM           = CSL_SDRAM_SDCR1_NM_DEFAULT;
     sdramCfg.CasLatency   = CSL_SDRAM_SDCR1_CL_DEFAULT;
     sdramCfg.bit11to9Lock = CSL_SDRAM_SDCR1_BIT_11_9_LOCK_DEFAULT;
     sdramCfg.ibankPos     = CSL_SDRAM_SDCR1_IBANK_DEFAULT;
     sdramCfg.ebank        = CSL_SDRAM_SDCR1_EBANK_DEFAULT;
     sdramCfg.pageSize     = CSL_SDRAM_SDCR1_PAGESIZE_DEFAULT;
     sdramCfg.selfRefresh  = CSL_SDRAM_SDCR2_SR_DEFAULT;
     sdramCfg.pdMode       = CSL_SDRAM_SDCR2_PD_DEFAULT;
     sdramCfg.pdwr         = CSL_SDRAM_SDCR2_PDWR_DEFAULT;
     sdramCfg.pasr         = CSL_SDRAM_SDCR2_PASR_DEFAULT;
     sdramCfg.rowSize      = rowSize;
     sdramCfg.ibankPos     = CSL_SDRAM_SDCR2_IBANK_POS_DEFAULT;
     sdramCfg.sdramDrive   = CSL_SDRAM_SDCR2_SDRAM_DRIVE_DEFAULT;
     sdramCfg.bit9to1Lock  = CSL_SDRAM_SDCR2_BIT_9_1_LOCK_DEFAULT;

     sdramTimr.tRAS        = CSL_SDRAM_TRAS_VAL;
     sdramTimr.tRC         = CSL_SDRAM_TRC_VAL;
     sdramTimr.tRRD        = CSL_SDRAM_TRRD_VAL;
     sdramTimr.tRFC        = CSL_SDRAM_TRFC_VAL;
     sdramTimr.tRP         = CSL_SDRAM_TRP_VAL;
     sdramTimr.tRCD        = CSL_SDRAM_TRCD_VAL;
     sdramTimr.tWR         = CSL_SDRAM_TWR_VAL;
     sdramTimr.tXS         = CSL_SDRAM_TXS_VAL;
     sdramTimr.refRate     = CSL_SDRAM_REFRATE_VAL;


     /* Configure SDRAM settings */
     status = SDRAM_config(hEmif, &sdramCfg, &sdramTimr);
     if(status != CSL_SOK)
     {
        printf("EMIF SDRAM Config Failed!!\n");
        return(result);
     }

     for(i=0;i<SDRAM_DELAY_CYCLES;i++){;}

     /* SDRAM power down mode is enabled */
     status = SDRAM_enablePowerDownMode(hEmif);
     printf("\nSDRAM is in power down mode!\n");

     for(i=0;i<SDRAM_DELAY_CYCLES;i++){;}

     /* SDRAM power down mode is disabled */
     status = SDRAM_disablePowerDownMode(hEmif);
     printf("\nSDRAM is out of power down mode!\n");

     /* SDRAM self refresh mode is enabled */
     status = SDRAM_enableSelfRefreshMode(hEmif);
     printf("\nSDRAM is in self refresh mode!\n");

     for(i=0;i<SDRAM_DELAY_CYCLES;i++){;}

     /* SDRAM self refresh mode is disabled */
     status = SDRAM_disableSelfRefreshMode(hEmif);
     printf("\nSDRAM is out of self refresh mode!\n");


     return status;
 }






