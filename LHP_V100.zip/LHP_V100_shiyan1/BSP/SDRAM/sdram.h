
#ifndef _SDRAM_H_
#define _SDRAM_H_

#ifdef __cplusplus
extern "C" {
#endif

#define SDRAM_DELAY_CYCLES  (4096)
#define SDRAM_BUF_SIZE      (1024)


/*7.6875MB is available at CS. Device has 8MB*/
#define CSL_SDRAM_TOTAL_LEN_IN_BYTE   0x7B0000
/*This value is for CS. Device is 4M x 16-bit*/
#define CSL_SDRAM_TOTAL_LEN_IN_WORD   0x3D8000
/*This value is for CS. Device can be considered as a 2M x 32-bit*/
#define CSL_SDRAM_TOTAL_LEN_IN_DWORD  0x1EC000

#define CSL_SDRAM_TEST_BUFFER_WORD_COUNT   1024
#define CSL_SDRAM_USE_ALIGNED_BUFFER       TRUE
#define CSL_SDRAM_BUFFER_ALIGN_BOUNDARY    32
#define CSL_SDRAM_TEST_START_OFFSET        0

#define CSL_SDRAM_DATA_WORD_ADDR  0x28000
#define CSL_SDRAM_DMA3_BYTE_ADDR  0x01000000

#define CSL_SDRAM_DMA_CHAN        CSL_DMA_CHAN15


CSL_Status CSL_sdramDmaTransferTest(void);
CSL_Status CSL_sdramConfDmaWriteChan(Uint32 dDestWordOffset, Uint16 numOfWords);
CSL_Status CSL_sdramConfDmaReadChan(Uint32 dSrcWordOffset, Uint16 numOfWords);
static CSL_Status CSL_setupSDRAM(void);


#ifdef __cplusplus
}
#endif

#endif /*_SDRAM_H_*/

