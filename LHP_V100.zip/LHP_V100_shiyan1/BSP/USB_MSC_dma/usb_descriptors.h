#ifndef USB_DESCRIPTORS_H
#define USB_DESCRIPTORS_H
#include "csl_msc.h"

extern char *stringDescriptor[];
extern CSL_MscRequestStruct USB_ReqTable[];
extern CSL_MscLunAttribApp lunAttr;

/* TI C5505 USB Product Id and Vendor Id */
//Uint16    pId = 0x5509;
extern Uint16    pId;
extern Uint16    vId;




#endif
