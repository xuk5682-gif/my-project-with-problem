/* ============================================================================
 * �� SD ��ӳ��� MSC �� LUN0��

  AppMediaInit() ����� ATA_systemInit()����Ҫʱ chk_mmc() ������/MBR/BR��

  AppRead/WriteMedia() �ڲ����� MMC_readNSectors/ MMC_writeNSectors �� ATA_read/writeSector��

  AppGetMediaSize() ������������������ mmcsdHandle->cardObj->totalSectors �� ATA ���㣩
 * ============================================================================
 */

#ifndef MSC_MEDIA_H
#define MSC_MEDIA_H

#include "ata_.h"
#include "csl_msc.h"
#include "csl_mmcsd_ataIf.h"


/* ATA data structure definitions */
extern AtaMMCState    ataMMCState;
extern AtaState       ATALogicalUnit[2];
extern AtaUint16      _AtaBuffer[ATA_WORDS_PER_PHY_SECTOR];
extern AtaMMCState    *gpstrMMCState;


#ifdef USE_ATA_NO_SWAP
/* This variable controls the DMA word swap and MMCSD endian mode. */
extern AtaUint16          ATA_No_Swap;
#endif

/**
 *  \brief  Function to initialize the media
 *
 *  \param  lunNo    - Logical unit number
 *
 *  \return Media status
 */
CSL_MscMediaStatus AppMediaInit(Uint16 lunNo);

/**
 *  \brief  Function to get the media size
 *   Note: This function returns number of sectors available
 *   on the media.
 *
 *  \param  lunNo    - Logical unit number
 *
 *  \return Number of sectors on the media
 */
Uint32 AppGetMediaSize(Uint16 lunNo);

/**
 *  \brief  Function to know the media status
 *
 *  \param  lunNo    - Logical unit number
 *
 *  \return Media status
 */
CSL_MscMediaStatus AppGetMediaStatus (Uint16 lunNo);

/**
 *  \brief  Function to write data to storage media
 *
 *  \param  lunNo    - Logical unit number
 *  \param  srcptr   - Data buffer pointer
 *  \param  LBA      - LBA to read data from
 *  \param  lbaCnt   - Number of LBAs to read
 *
 *  \return Media status
 */
CSL_MscMediaStatus AppWriteMedia (Uint16    lunNo,
                                  Uint16    *srcptr,
                                  Uint32    LBA,
                                  Uint16    lbaCnt);

/**
 *  \brief  Function to read data from storage media
 *
 *  \param  lunNo    - Logical unit number
 *  \param  destptr  - Data buffer pointer
 *  \param  LBA      - LBA to read data from
 *  \param  lbaCnt   - Number of LBAs to read
 *
 *  \return Media status
 */
CSL_MscMediaStatus AppReadMedia (Uint16    lunNo,
                                 Uint16    *destptr,
                                 Uint32    LBA,
                                 Uint16    lbaCnt);

/**
 *  \brief  Function to Eject media
 *
 *  \param  lunNo  - Logical unit number
 *
 *  \return Media status
 */
CSL_MscMediaStatus AppMediaEject(Uint16 lunNo);

/**
 *  \brief  Function to lock media
 *
 *  \param  lunNo   - Logical unit number
 *  \param  status  - Media lock status
 *
 *  \return Media status
 */
CSL_MscMediaStatus AppLockMedia(Uint16                   lunNo,
                                CSL_MscMediaLockStatus   status);

#endif
