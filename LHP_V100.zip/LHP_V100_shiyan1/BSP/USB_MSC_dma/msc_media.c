
#include "chk_mmc.h"
#include "msc_media.h"
#include "sd_card.h"
#include "common.h"


#pragma DATA_ALIGN(glbaCacheBuff, 32);
Uint16 glbaCacheBuff[256 * CACHED_SECT_COUNT];



/* ATA data structure definitions */
AtaMMCState    ataMMCState;
AtaState       ATALogicalUnit[2];
#pragma DATA_ALIGN(_AtaBuffer, 32);
AtaUint16      _AtaBuffer[ATA_WORDS_PER_PHY_SECTOR];
AtaMMCState    *gpstrMMCState = &ataMMCState;


Uint16 gStartCaching = 0;
Uint32 glbaStartNum = 0;
Uint16 glbaCaheCnt = 0;
Uint16 temp;


/**
 *  \brief  Function to initialize the media
 *����ʼ�� USB MSC��Mass Storage Class���豸��ʹ�õĴ洢���ʣ����� SD �� �� NAND �ȣ�������������ȷʶ�𲢷����������
 *�����߼���Ԫ�� (lunNo)����ʼ�� SD �������������ʣ��� ATA �ļ�ϵͳ�ӿڣ�ʹ USB MSC �ܷ��ʸý��ʣ������ؽ���״̬��
 *  \param  lunNo    - Logical unit number
 *���� MMC/SD ���ֽ���Endian��ģʽ��
  ��ʼ�� ATA �ļ�ϵͳ��
  ��� SD ���Ƿ������
  ���ݳ�ʼ�����������Ӧ�Ľ���״̬���ɹ������̡�δ���룩��
 *  \return Media status
 */
CSL_MscMediaStatus AppMediaInit(Uint16 lunNo)
{
    CSL_MscMediaStatus    retMediaStat;
    AtaError              mediaError;
    unsigned int           diskType;

    mediaError = ATA_ERROR_NONE;

#if (defined(CHIP_C5505_C5515) || defined(CHIP_C5504_C5514) || defined(CHIP_C5517) || defined(CHIP_C5535) || defined(CHIP_C5545))

    /* Sector zero  data should always be read by ATA file system in little
       endian mode. Change the endian mode to big after sector zero read.
       This is applicable to chip C5515. On C5505 endian mode is always
       little */
    /* ����ĳЩ TI DSP���� C5515��C5517 �ȣ����ڶ�ȡ SD ���� �� 0 ������MBR/���������� ʱ��
       Ҫ��ʹ�� С��ģʽ����ȡ������л��� ���ģʽ��*/
    MMC_setEndianMode(mmcsdHandle,
                      CSL_MMCSD_ENDIAN_LITTLE,
                      CSL_MMCSD_ENDIAN_LITTLE);
#endif

    /* For partitioned disk, 'diskType' should be 0
       and for unpartiotioned disk, it should be 1
     */
     /* chk_mmc() function is used to check the partition type of
        SD card.
        ATA_systemInit() function needs to be called
        with 'diskType' set to 0 before calling chk_mmc().
        chk_mmc() function will check whether the disk is partitioned
        or unpartitioned. If disk is not partitioned it will change the
        'diskType' value to 1 otherwise it will not change the diskType value.
        After calling chk_mmc() if 'diskType' is not '0' , It means that
        the SD card is not partitioned and ATA_systemInit() needs to be
        called with 'diskType' value modified by chk_mmc() function */

#ifdef CSL_CHECK_DISK_PARTITION

    diskType = 0;   //��ʼ���������ͱ�־  0 �� �������̣��з�������   1 �� δ��������
    /* Call ATA_systemInit() to initialize some values which are
      used by chk_mmc() function */
    mediaError = ATA_systemInit(&ATALogicalUnit[lunNo], diskType);

    chk_mmc(&ATALogicalUnit[lunNo], &diskType);  //��� SD �������������ѡ��
    if(diskType != 0)
    {
        mediaError = ATA_systemInit(&ATALogicalUnit[lunNo], diskType);
    }

#else

    diskType = 1;
    mediaError = ATA_systemInit(&ATALogicalUnit[lunNo], diskType);

#endif

#if (defined(CHIP_C5505_C5515) || defined(CHIP_C5504_C5514) || defined(CHIP_C5517) || defined(CHIP_C5535) || defined(CHIP_C5545))
    MMC_setEndianMode(mmcsdHandle,
                      CSL_MMCSD_ENDIAN_BIG,
                      CSL_MMCSD_ENDIAN_BIG);
#endif

    if (mediaError == ATA_ERROR_NONE)
    {
        retMediaStat = CSL_MSC_MEDIACCESS_SUCCESS;
    }
    else if(mediaError == ATA_ERROR_BAD_MEDIA)
    {
        retMediaStat = CSL_MSC_MEDIACCESS_BADMEDIA;
    }
    else if((mediaError == ATA_ERROR_MEDIA_NOT_FOUND) ||
            (mediaError == ATA_ERROR_MEDIA_REMOVED))
    {
        retMediaStat = CSL_MSC_MEDIACCESS_NOTPRESENT;
    }

    return(retMediaStat);
}

/**
 *  \brief  Function to read data from storage media
 *������ LBA �Ӵ洢���ʣ�SD/ MMC�������ݵ������������ѵײ������ӳ��� USB MSC �Ľ���״̬��
 * ������ĳ���߼���Ԫ��lunNo���������Ƿ���ɹ�/���ʻ�/δ�忨/�����״̬��
 *  \param  lunNo    - Logical unit number
 *  \param  destptr  - Data buffer pointer
 *  \param  LBA      - LBA to read data from
 *  \param  lbaCnt   - Number of LBAs to read
 *
 *  \return Media status
 */
CSL_MscMediaStatus AppReadMedia (Uint16    lunNo,
                                 Uint16    *destptr,
                                 Uint32    LBA,
                                 Uint16    lbaCnt)
{
    CSL_MscMediaStatus    retMediaStat;
    AtaError              mediaError;
#ifdef USE_ATA_NO_SWAP
    AtaUint16             ATA_No_Swap_sav;

    ATA_No_Swap_sav = ATA_No_Swap;
    ATA_No_Swap     = 1;
#endif
    mediaError = ATA_ERROR_NONE;

#ifdef  CSL_MMCSD_MULTISECT_TXFER

    ATALogicalUnit[lunNo].CurrentWord = 0;
    if((lbaCnt < CACHED_SECT_COUNT) && (gStartCaching == 0))
    {
        //mediaError = ATA_readSector(LBA, &ATALogicalUnit[lunNo], (AtaUint16*)destptr, 0);
        mediaError = MMC_readNSectors(ATALogicalUnit[lunNo].pAtaMediaState,
                                      (AtaUint16*)destptr, LBA, 1);
    }
    else
    {
        if(gStartCaching == 0)
        {
            gStartCaching = 1;
            glbaCaheCnt   = 0;
        }
    }

    if(gStartCaching == 1)
    {
        if(glbaCaheCnt == 0)
        {
            mediaError = MMC_readNSectors(ATALogicalUnit[lunNo].pAtaMediaState,
                                          (AtaUint16*)glbaCacheBuff,
                                          LBA,
                                          CACHED_SECT_COUNT);
        }

        for(temp = 0; temp < 256; temp++)
        {
            destptr[temp] = glbaCacheBuff[temp + (glbaCaheCnt * 256)];
        }

        glbaCaheCnt++;

        if(glbaCaheCnt == CACHED_SECT_COUNT)
        {
            gStartCaching = 0;
            glbaCaheCnt = 0;
        }
    }

#else

    //mediaError = ATA_readSector(LBA, &ATALogicalUnit[lunNo], (AtaUint16*)destptr, 0);
    mediaError = MMC_readNSectors(ATALogicalUnit[lunNo].pAtaMediaState,
                                  (AtaUint16*)destptr, LBA, 1);

#endif

    if(mediaError == ATA_ERROR_NONE)
    {
        retMediaStat = CSL_MSC_MEDIACCESS_SUCCESS;
    }
    else if (mediaError == ATA_ERROR_BAD_MEDIA)
    {
        retMediaStat = CSL_MSC_MEDIACCESS_BADMEDIA;
    }
    else if((mediaError == ATA_ERROR_MEDIA_NOT_FOUND) ||
            (mediaError == ATA_ERROR_MEDIA_REMOVED))
    {
        retMediaStat = CSL_MSC_MEDIACCESS_NOTPRESENT;
    }
    else if(mediaError == ATA_ERROR_DISK_FULL)
    {
       retMediaStat = CSL_MSC_MEDIACCESS_OVERFLOW;
    }

#ifdef USE_ATA_NO_SWAP
    ATA_No_Swap = ATA_No_Swap_sav;
#endif

    return (retMediaStat);
}

/**
 *  \brief  Function to write data to storage media
 *
 *  \param  lunNo    - Logical unit number
 *  \param  srcptr   - Data buffer pointer
 *  \param  LBA      - LBA to read data from
 *  \param  lbaCnt   - Number of LBAs to read
 *
 *  \return Media status
 */
CSL_MscMediaStatus AppWriteMedia (Uint16    lunNo,
                                  Uint16    *srcptr,
                                  Uint32    LBA,
                                  Uint16    lbaCnt)
{
    CSL_MscMediaStatus    retMediaStat;
    AtaError              mediaError;
#ifdef USE_ATA_NO_SWAP
    AtaUint16             ATA_No_Swap_sav;

    ATA_No_Swap_sav = ATA_No_Swap;
    ATA_No_Swap     = 1;
#endif
    mediaError = ATA_ERROR_NONE;

#ifdef  CSL_MMCSD_MULTISECT_TXFER

    if((lbaCnt < CACHED_SECT_COUNT) && (gStartCaching == 0))
    {
        //mediaError = ATA_writeSector(LBA,&ATALogicalUnit[lunNo],(AtaUint16*)srcptr, 0);
        mediaError = MMC_writeNSectors(ATALogicalUnit[lunNo].pAtaMediaState,
                                       (AtaUint16*)srcptr, LBA, 1);
    }
    else
    {
        if(gStartCaching == 0)
        {
            gStartCaching = 1;
            glbaStartNum  = LBA;
            glbaCaheCnt   = 0;
        }
    }

    if(gStartCaching == 1)
    {

        for(temp = 0; temp < 256; temp++)
        {
            glbaCacheBuff[temp + (glbaCaheCnt * 256)] = srcptr[temp];
        }

        mediaError = ATA_ERROR_NONE;
        glbaCaheCnt++;

        if(glbaCaheCnt == CACHED_SECT_COUNT)
        {
            mediaError = MMC_writeNSectors(ATALogicalUnit[lunNo].pAtaMediaState,
                                           (AtaUint16*)glbaCacheBuff,
                                           glbaStartNum,
                                           CACHED_SECT_COUNT);
            glbaCaheCnt = 0;
            gStartCaching = 0;
        }
    }

#else

    //mediaError = ATA_writeSector(LBA,&ATALogicalUnit[lunNo],(AtaUint16*)srcptr, 0);
    mediaError = MMC_writeNSectors(ATALogicalUnit[lunNo].pAtaMediaState,
                                   (AtaUint16*)srcptr, LBA, 1);

#endif

    if(mediaError == ATA_ERROR_NONE)
    {
        retMediaStat = CSL_MSC_MEDIACCESS_SUCCESS;
    }
    else if(mediaError == ATA_ERROR_BAD_MEDIA)
    {
        retMediaStat = CSL_MSC_MEDIACCESS_BADMEDIA;
    }
    else if((mediaError == ATA_ERROR_MEDIA_NOT_FOUND)||
            (mediaError == ATA_ERROR_MEDIA_REMOVED))
    {
        retMediaStat = CSL_MSC_MEDIACCESS_NOTPRESENT;
    }
    else if(mediaError == ATA_ERROR_DISK_FULL)
    {
        retMediaStat = CSL_MSC_MEDIACCESS_OVERFLOW;
    }

#ifdef USE_ATA_NO_SWAP
    ATA_No_Swap = ATA_No_Swap_sav;
#endif

    return (retMediaStat);
}

/**
 *  \brief  Function to Eject media
 *
 *  \param  lunNo  - Logical unit number
 *
 *  \return Media status
 */
CSL_MscMediaStatus AppMediaEject(Uint16    lunNo)
{
    return(CSL_MSC_MEDIACCESS_SUCCESS);
}

/**
 *  \brief  Function to lock media
 *
 *  \param  lunNo   - Logical unit number
 *  \param  status  - Media lock status
 *
 *  \return Media status
 */
CSL_MscMediaStatus AppLockMedia(Uint16                   lunNo,
                                CSL_MscMediaLockStatus   status)
{
    return(CSL_MSC_MEDIACCESS_SUCCESS);
}

/**
 *  \brief  Function to know the media status
 *
 *  \param  lunNo    - Logical unit number
 *
 *  \return Media status
 */
CSL_MscMediaStatus AppGetMediaStatus(Uint16    lunNo)
{
    return CSL_MSC_MEDIACCESS_SUCCESS;
}

/**
 *  \brief  Function to get the media size
 *   Note: This function returns number of sectors available
 *   on the media.
 *
 *  \param  lunNo    - Logical unit number
 *
 *  \return Number of sectors on the media
 */
Uint32 AppGetMediaSize(Uint16 lunNo)
{
    Uint32 size;

    //size = (Uint32)ATA_diskSize(&ATALogicalUnit[lunNo]);
    //size = mmcsdHandle->cardObj->cardCapacity;

    size = mmcsdHandle->cardObj->totalSectors;
// mwei avoid overflow
#if 0
    size = ((size)*(1024));
    size = ((size)/(512));
#else

    //size = (size)*2;
#endif

    return(size);
}
