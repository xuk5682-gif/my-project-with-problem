#ifndef COMMON_H
#define COMMON_H

#include <log.h>
#include <std.h>
#include <mbx.h>
#include <sem.h>
#include <tsk.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include"uart.h"

#include "csl_general.h"
#include "csl_types.h"


#define ENABLE_DEBUG_PRINT 1
#if ENABLE_DEBUG_PRINT
//#define CSL_USB_DEBUG_PRINT printf
#define CSL_USB_DEBUG_PRINT uart_printf
#else
#define CSL_USB_DEBUG_PRINT(...)
#endif

#define   SYSCLK   getSysClk()*1000



/* This macro is used to include or exclude the code to configure
 * the MMCSD interrupts during DMA mode operation. If this macro is not defined,
 * USB mass storage example works with out using MMCSD interrupts for checking
 * MMCSD Data transfer completion
 * MMCSD Data transfer completion.
 *
 * �ر� MMC/SD �жϣ�
 * - ע�͵��������к궨�壬configDmaforMmcSd() �оͲ���ȥʹ�� PROG0/PROG2 �жϣ�
 *   �Ӷ�������� i2s1_mmc1_tx_isr ����Ĭ��ռλ ISR��
 * - MMC/SD ��д��Ȼ���Թ�����ֻ�ǲ������� MMCSD �жϣ�����ʹ����ѯ/ͬ����ʽ�ȴ���ɡ�
 *  */
#define CSL_MMCSD_INTR_ENABLE         (1u)

/* This macro is used to include or exclude the code to read multiple sectors
 * at a time from the SD card. This code uses "MMC_readNSectors" and
 * "MMC_writeNSectors" APIs instead of "ATA_readSector" and "ATA_writeSector"
 * respectively . This code reads/writes multiple sectors only when there is
 * a request from the host to read/write CACHED_SECT_COUNT number of sectors.
 * This macro needs to be defined to include multiple read/write sector code
 */
#define CSL_MMCSD_MULTISECT_TXFER   (1u)

/* This macro is used to include or exclude the code to check
  the SD card partition type. This code is useful to determine
  the exact value for disk type parameter of ATA_systemInit() API */
#define CSL_CHECK_DISK_PARTITION    (1u)

/* This macro decides the number of multiple sectors read from or
 * written to the SD card at a time */
#define CACHED_SECT_COUNT           (16u)



/*----- Mailboxes -----*/
extern MBX_Obj MBX_musb;
extern MBX_Obj MBX_msc;

/*----- Semaphores -----*/
/*USB�ź���*/
extern SEM_Obj SEM_MUSBMainTaskExited;
extern SEM_Obj SEM_MUSBMSCTaskExited;
extern SEM_Obj SEM_AbortTransferDone;
extern SEM_Obj SEM_DisconnectDeviceDone;
extern SEM_Obj SEM_ConnectDeviceDone;
extern SEM_Obj SEM_ResetDeviceDone;
extern SEM_Obj SEM_ClearEndpointStalltDone;
extern SEM_Obj SEM_MUSBDMARxComplete;
extern SEM_Obj SEM_MUSBDMATxComplete;
/*SPI DMA�ź���*/
extern SEM_Handle  s_notifySem;

/*----- Tasks -----*/
extern TSK_Obj TSK_MUSBMSCTask;
extern TSK_Obj TSK_MUSBMainTask;

/* Semaphore to indicate DMA action complete */
extern SEM_Obj  SEM_mmcsd_dmaTransferDone;



#endif
